self.assetsManifest = {
  "version": "CWbxN7kn",
  "assets": [
    {
      "hash": "sha256-zaLWJTjlmv1kP5sNx6NrZLD4d5wZ6nMBS9EH+62HBrk=",
      "url": "SistemaAlmacen.Client.styles.css"
    },
    {
      "hash": "sha256-itxgC9CUXgA0s57EK2bjpHhRABlrtO8ndt+ThYI7Lus=",
      "url": "_content/Microsoft.AspNetCore.Components.WebAssembly.Authentication/AuthenticationService.js"
    },
    {
      "hash": "sha256-gqucMFIuVF5boR/O3y/viDH5uyXJvkbdVMJrE9N+f00=",
      "url": "_framework/Microsoft.AspNetCore.Authorization.286cdd0mnj.wasm"
    },
    {
      "hash": "sha256-EbFyKid1qtnkJa2eCV02mgtXNS7mZhEY+6O2Cp0Jbwc=",
      "url": "_framework/Microsoft.AspNetCore.Components.Authorization.btlik35l51.wasm"
    },
    {
      "hash": "sha256-57t2ZKMLZfQOSsXNiNjXO8u1+yWfSHjzAr/To1NRW0k=",
      "url": "_framework/Microsoft.AspNetCore.Components.Forms.b7y73c8sd4.wasm"
    },
    {
      "hash": "sha256-yPMQHrHNo42HyIm6/bA/SIX61/7k22iPi8EbD6rK6xg=",
      "url": "_framework/Microsoft.AspNetCore.Components.Web.k10g806xum.wasm"
    },
    {
      "hash": "sha256-2v52XzJgJ6ozpnflImqfaMeXSfOJalZ2v7++eLcKRKg=",
      "url": "_framework/Microsoft.AspNetCore.Components.WebAssembly.Authentication.q8iyif4pxc.wasm"
    },
    {
      "hash": "sha256-niYTFW5FSoDH2+Ly40UDVo82CLSh45bcn60OHn3RKlc=",
      "url": "_framework/Microsoft.AspNetCore.Components.WebAssembly.au6z0bcsrs.wasm"
    },
    {
      "hash": "sha256-kHWRMmhRUqt14oDEP4wiUWv0I1Pdakmd7UimVDCMMAk=",
      "url": "_framework/Microsoft.AspNetCore.Components.o6y2k6vgc3.wasm"
    },
    {
      "hash": "sha256-KeYQjojYcSdQ7Cg7kPUrBLJ8FDUsYtcokMMYf9p5aoI=",
      "url": "_framework/Microsoft.AspNetCore.Metadata.59ibtucemk.wasm"
    },
    {
      "hash": "sha256-p2hOZdP04ox2bhy6/B/+fGJDWwWmx+S0Zgr8fTCeZgc=",
      "url": "_framework/Microsoft.Bcl.Cryptography.3pa69hqvhn.wasm"
    },
    {
      "hash": "sha256-efSJhSlgBbB+4MSberm4qW6QhDCp9A6veL+Oq9tOQ0s=",
      "url": "_framework/Microsoft.CSharp.hejdt5q9w7.wasm"
    },
    {
      "hash": "sha256-COWwzg73Z3/o08f86sS51xhS4Ya6UXTEzWvXeOnbv00=",
      "url": "_framework/Microsoft.DotNet.HotReload.WebAssembly.Browser.0ql05aqe1d.lib.module.js"
    },
    {
      "hash": "sha256-I/8bN7bvY07yPXS3SfS5fxtkCkWeIg2Dd/P37Rv44vg=",
      "url": "_framework/Microsoft.DotNet.HotReload.WebAssembly.Browser.1vk97ay1th.wasm"
    },
    {
      "hash": "sha256-qGEjY6VT2kt4ucUDReYxSt/AZBfFiBd5i7rkwP8WEFE=",
      "url": "_framework/Microsoft.Extensions.Configuration.Abstractions.gydskqrdmp.wasm"
    },
    {
      "hash": "sha256-hTi+lsmFyO+ohu81RCsWT31+ymlbM74tJEDpvEuN/qE=",
      "url": "_framework/Microsoft.Extensions.Configuration.Binder.jagglvwcdi.wasm"
    },
    {
      "hash": "sha256-6YRgll2ZRHI7X3l5jDKbbC6W5OGTmoAtT8EJqIHrhw0=",
      "url": "_framework/Microsoft.Extensions.Configuration.FileExtensions.lhv6s59pp1.wasm"
    },
    {
      "hash": "sha256-vEXfqN8qDFuhGvpgagVTNRsG1kmgCCceAIvCg/q5X3M=",
      "url": "_framework/Microsoft.Extensions.Configuration.Json.ovhjhq0url.wasm"
    },
    {
      "hash": "sha256-gAo2vNKc6IguqLYysEBH6sm0iSchu3oGbYQ3Aq5PtSM=",
      "url": "_framework/Microsoft.Extensions.Configuration.k3gsyevy27.wasm"
    },
    {
      "hash": "sha256-IIfEv8464evpIZhWH9CEVKytwJjFayCOQNxwFMSzewg=",
      "url": "_framework/Microsoft.Extensions.DependencyInjection.Abstractions.woum050g24.wasm"
    },
    {
      "hash": "sha256-jxt6IZ6EWYrltHD5SctKq9exI4IgXFWN8HHCGTGXWBA=",
      "url": "_framework/Microsoft.Extensions.DependencyInjection.dpa1450tku.wasm"
    },
    {
      "hash": "sha256-DT14V4vi9XUlFVFm3GmOzlxHBod9icve1tfVRr/16Dc=",
      "url": "_framework/Microsoft.Extensions.Diagnostics.1jey3rxiy8.wasm"
    },
    {
      "hash": "sha256-cRs5WmY9zg24WDKu0SNxfrTJSAWbn8nvTV4rqWaMxnw=",
      "url": "_framework/Microsoft.Extensions.Diagnostics.Abstractions.fkr8no9xuy.wasm"
    },
    {
      "hash": "sha256-RjswNfP4mBVN0iMFavEXD7bu4e4Sz7HV16ox6gIV4XU=",
      "url": "_framework/Microsoft.Extensions.FileProviders.Abstractions.21el9em0un.wasm"
    },
    {
      "hash": "sha256-ln/KyeKj5JrveXR6t0vxLSq821AqWW9mZ2qT/L+ES/k=",
      "url": "_framework/Microsoft.Extensions.FileProviders.Physical.6xc4mci3lw.wasm"
    },
    {
      "hash": "sha256-/omCzFRHNzhzfobQM7ycUMV5otX5+bIc/MagoIWI8/0=",
      "url": "_framework/Microsoft.Extensions.FileSystemGlobbing.qthbzihrxq.wasm"
    },
    {
      "hash": "sha256-6DzIf0hf+dxG6YyvkhCKRQplQmzo7XWuHH9ngbrlnDU=",
      "url": "_framework/Microsoft.Extensions.Logging.Abstractions.8weyptjtvc.wasm"
    },
    {
      "hash": "sha256-FEpTWBY+QUqwgBqB9uvDQO9eSFjq9S3rPQIaxVCVnaw=",
      "url": "_framework/Microsoft.Extensions.Logging.op9zaw9pvp.wasm"
    },
    {
      "hash": "sha256-oMBQFO2V/s0C8K6axybP94kUSUYD9fXaYKkooTHJQ4o=",
      "url": "_framework/Microsoft.Extensions.Options.ConfigurationExtensions.oic5e9iprm.wasm"
    },
    {
      "hash": "sha256-5zFrr6qDicK+jGfTglhuenZJfjcPRePRnMy7C6bhCZ0=",
      "url": "_framework/Microsoft.Extensions.Options.ldnbby568o.wasm"
    },
    {
      "hash": "sha256-n58JBASBWj2pbdb/VpoMiGC1xh+6OcVDccrku7x55Bg=",
      "url": "_framework/Microsoft.Extensions.Primitives.xoe0uq16op.wasm"
    },
    {
      "hash": "sha256-mJ4FsGe9wRo92tmuRPuLefQ+YQY5o+KXsjE6xYrF82A=",
      "url": "_framework/Microsoft.Extensions.Validation.gqyba4siw3.wasm"
    },
    {
      "hash": "sha256-2ZsMnds59dSHYhu5KzXaGE1gQeyjc+ZM5wi6+jj8M0E=",
      "url": "_framework/Microsoft.IdentityModel.Abstractions.bb9gljrr42.wasm"
    },
    {
      "hash": "sha256-8H4b4HSsImdM8Bs0G8mypE+oy6CM45G4GwYhKTj7UuI=",
      "url": "_framework/Microsoft.IdentityModel.JsonWebTokens.wsyb2e46l9.wasm"
    },
    {
      "hash": "sha256-SHi56dJlQX/HxVSiqpbxVaGPaR86C0FrfQg7Rqe3ies=",
      "url": "_framework/Microsoft.IdentityModel.Logging.o8o4sy1fv6.wasm"
    },
    {
      "hash": "sha256-nDKMrnv/osDdzy4YiT9q32K4Gwh/N4r03kBdq5X9xCo=",
      "url": "_framework/Microsoft.IdentityModel.Tokens.sut5rvh7q1.wasm"
    },
    {
      "hash": "sha256-9MGmvPvfhxv9bWwO5MaF9nzkGOhoslRrpxqSCctJetM=",
      "url": "_framework/Microsoft.JSInterop.WebAssembly.4mnezrwisk.wasm"
    },
    {
      "hash": "sha256-N1EMrB7k/3Mcs7qqnPDno0O+f2WfkwTpYOsFCf93ESU=",
      "url": "_framework/Microsoft.JSInterop.vei8iss1f3.wasm"
    },
    {
      "hash": "sha256-VJr17rD/xtXPxO3023r+5bjX4j8at1hS29docyilIAQ=",
      "url": "_framework/Microsoft.VisualBasic.Core.s01ygrxnou.wasm"
    },
    {
      "hash": "sha256-hqGg6WrVnAshSdahy+lhr6PDoA5dZ01GreRNL89vNJI=",
      "url": "_framework/Microsoft.VisualBasic.mcss3c947q.wasm"
    },
    {
      "hash": "sha256-5UCTTjIczf3zokmq+OYIf9m0EPP5kh+8o0Z8Ae9MuQg=",
      "url": "_framework/Microsoft.Win32.Primitives.r8e0zxpfe0.wasm"
    },
    {
      "hash": "sha256-in9vy9BpwMVcZOY+GAqjnIghXNrMqqToeJX82sIDNX8=",
      "url": "_framework/Microsoft.Win32.Registry.2ywbsi2vy8.wasm"
    },
    {
      "hash": "sha256-JNYOTyANdvhU43PCHcQtpBPMrwUYcTEHqbPdP6ZX2zU=",
      "url": "_framework/SistemaAlmacen.Client.g99x1mfqjj.wasm"
    },
    {
      "hash": "sha256-O+af2xheXSusDrxjkX7Lnc9724HgSTDmNpVfbt/4jn8=",
      "url": "_framework/SistemaAlmacen.Client.l8tfk90is2.pdb"
    },
    {
      "hash": "sha256-Dopu1UWPFMBMTqZwyFBoLMVS61nlPD+EHO/81SbZgaU=",
      "url": "_framework/SistemaAlmacen.Shared.6ut0baaco8.pdb"
    },
    {
      "hash": "sha256-3A8RU8KUl4lQs8OlZgmUMWPS/1xb0v9QsAmc3R/OPjY=",
      "url": "_framework/SistemaAlmacen.Shared.gj6bebgdzw.wasm"
    },
    {
      "hash": "sha256-DKbQ1XCUoVlDqDBwtLDzebj3HHSaXnZrJeofFxJ/uyE=",
      "url": "_framework/System.0b02oc3xxl.wasm"
    },
    {
      "hash": "sha256-9PLIWHk1UT2n5bCtKqQD2Kr4wi+MMk1IRov7++9W0yY=",
      "url": "_framework/System.AppContext.s4abp71nh7.wasm"
    },
    {
      "hash": "sha256-dxRQGPENvHYhqD9I9Oc8vI7mIdpz4yAHBZad8b+zsz0=",
      "url": "_framework/System.Buffers.bzczkplo2y.wasm"
    },
    {
      "hash": "sha256-2yjk6zyiUDyBeEsYTCzWj+KzCvfjf9nDjLmWzFb2bzE=",
      "url": "_framework/System.Collections.Concurrent.9z7rilffor.wasm"
    },
    {
      "hash": "sha256-7cvVoYQgMQImrYmSIY6RGBxQcq3pR/ve+FaCVoqgydE=",
      "url": "_framework/System.Collections.Immutable.5ej7i7eb90.wasm"
    },
    {
      "hash": "sha256-qGnK7bSHmHnsM5v73KAWsias0WXlVTgRkbh6Blfzz6k=",
      "url": "_framework/System.Collections.NonGeneric.sfutn45gdb.wasm"
    },
    {
      "hash": "sha256-LtBto3yGuqrp+Njt5yMiYoYto+nQtCo2y2YJVHqRzYY=",
      "url": "_framework/System.Collections.Specialized.qyjvd36pc5.wasm"
    },
    {
      "hash": "sha256-cMnpjKzbg15om+Y8X+6Pq6sgiA0pCIBlIybYjjF8Tlc=",
      "url": "_framework/System.Collections.wgddc6my5a.wasm"
    },
    {
      "hash": "sha256-acHAVccifVgjkzz/UXYMgcSSsLkC6rdIK18AboJX5Gk=",
      "url": "_framework/System.ComponentModel.Annotations.l9t1bzaiim.wasm"
    },
    {
      "hash": "sha256-WEPC4lqNOekCmORY7bolwYmMA2nW8F10MOIZPETe3xM=",
      "url": "_framework/System.ComponentModel.DataAnnotations.ooynghorwa.wasm"
    },
    {
      "hash": "sha256-BzqG/giD2mV5bjkwcMgs/aM73qamyq6PlKhWAg3TapY=",
      "url": "_framework/System.ComponentModel.EventBasedAsync.fin8t1radj.wasm"
    },
    {
      "hash": "sha256-t1SDKR/FXuHVkrW0rD/1sMQC9tOM+StJoZdyCQ4Pwpw=",
      "url": "_framework/System.ComponentModel.Primitives.hyjhgb1ga1.wasm"
    },
    {
      "hash": "sha256-20WJOsSAZZ6hm5RQNS2YidWYx8jV8eovZeDFRHUBBlc=",
      "url": "_framework/System.ComponentModel.TypeConverter.pnptfx4b59.wasm"
    },
    {
      "hash": "sha256-bukh+rqDxJMLEAsACjqQ3LmQOjvikpU4DstHs9hkbjw=",
      "url": "_framework/System.ComponentModel.meeq27uemk.wasm"
    },
    {
      "hash": "sha256-pNPb29OTmssYBaX9LDo+clFlgH7oiiIhJrJd13P5RHk=",
      "url": "_framework/System.Configuration.gtk5rogi73.wasm"
    },
    {
      "hash": "sha256-ubBgLSuRFUBaWm5cAwrVwDr7vRw5tnzrWSVnp/d7Of8=",
      "url": "_framework/System.Console.1qhgz03ru2.wasm"
    },
    {
      "hash": "sha256-PvA+EtzoiCVOFMjMSMzC4AnU/VwcbKkZg4+09CbdO/A=",
      "url": "_framework/System.Core.2ngkfg3yg5.wasm"
    },
    {
      "hash": "sha256-suvMaQr81TwtLvzWdAlSuROfdA2d6GPDmMa8jGEzzc0=",
      "url": "_framework/System.Data.Common.udkq2shnti.wasm"
    },
    {
      "hash": "sha256-2JeSS7vySk7/Ni9E7FiTV5FXpAtal+uRjFkRSgcF2Mk=",
      "url": "_framework/System.Data.DataSetExtensions.wi4567wuoc.wasm"
    },
    {
      "hash": "sha256-V6Y//2wcYi2zf+pQj2K0jGSG7YT9M7CoQUAbRO7C810=",
      "url": "_framework/System.Data.db1wnp1gfk.wasm"
    },
    {
      "hash": "sha256-KJ3PIQ1USf2DlQtxLup8HLtOgVTFe9pZQ1Z5PXBpQWc=",
      "url": "_framework/System.Diagnostics.Contracts.ow0x4fg7us.wasm"
    },
    {
      "hash": "sha256-R7/CjdGgjC3nP7HEVkFGrDoomZI5ldCItORV5rSUxzQ=",
      "url": "_framework/System.Diagnostics.Debug.tn6w3p7s31.wasm"
    },
    {
      "hash": "sha256-uNl987ZRqQ2dWPXEkPdUHGHOuMrSGGwmlgrYqPrkHv4=",
      "url": "_framework/System.Diagnostics.DiagnosticSource.45dj5ekgyb.wasm"
    },
    {
      "hash": "sha256-6BsW72orL4S7hfjoVEV0t03jo2X3QKj8pqW6x/EAyow=",
      "url": "_framework/System.Diagnostics.FileVersionInfo.g6ryqnt17q.wasm"
    },
    {
      "hash": "sha256-ThbDXYFwKmht16cMWPBrdH9qrPH1+QS7OU6MAOL8Slc=",
      "url": "_framework/System.Diagnostics.Process.esxdiea9kf.wasm"
    },
    {
      "hash": "sha256-suIfDtId2wyHzpffNeUam3d5WnAiYckKI9mnQi4eqhE=",
      "url": "_framework/System.Diagnostics.StackTrace.6639d23w2s.wasm"
    },
    {
      "hash": "sha256-T1dpe+4s/SjDJ/w4gB17LJZXTJ15l2XOcdtmWUV+XkQ=",
      "url": "_framework/System.Diagnostics.TextWriterTraceListener.pum8jcuwqx.wasm"
    },
    {
      "hash": "sha256-bSxTk24Le+PHZ4XvIpIJsLsDpLOkIwtO/v+YfgaMX5I=",
      "url": "_framework/System.Diagnostics.Tools.7fr7p137bw.wasm"
    },
    {
      "hash": "sha256-jHDKsp4uTgv/QFdgMTJKYAod9SMkpdRf196V4AFDRQI=",
      "url": "_framework/System.Diagnostics.TraceSource.0l88mb1brk.wasm"
    },
    {
      "hash": "sha256-I23cLcuhiEVt3ymNZwhTSPwSv076X22E01DY2qwIyVo=",
      "url": "_framework/System.Diagnostics.Tracing.vlhcpghauv.wasm"
    },
    {
      "hash": "sha256-K9ffth8eud/WyY0cSq6Em1MUxTU/+pLit+AjrAFP4Ng=",
      "url": "_framework/System.Drawing.Primitives.htr0037lv3.wasm"
    },
    {
      "hash": "sha256-CjtQI8/oyRM3JCLfF6JKR6ql2fMR/2SZlIRgxVDeZ+0=",
      "url": "_framework/System.Drawing.mxlchglgtf.wasm"
    },
    {
      "hash": "sha256-vKTBhE57D656SwUFeRy2ryAOYG//KOITnGPC3/d/pqY=",
      "url": "_framework/System.Dynamic.Runtime.g3w9i6nwr0.wasm"
    },
    {
      "hash": "sha256-ojpwUpuXTqHpY7HtX9c4569+f3axTA3c7Xa9Ggn3ml4=",
      "url": "_framework/System.Formats.Asn1.u475yku82u.wasm"
    },
    {
      "hash": "sha256-dJD9gqIAE3bEWH5+Z5p5YKfI8ftXd8ik/akPl9qRje0=",
      "url": "_framework/System.Formats.Tar.0v34f1354b.wasm"
    },
    {
      "hash": "sha256-mJEIPBuuXNX7EMVYlNFf/bkgXZ4YyNKcDScsIwY9goU=",
      "url": "_framework/System.Globalization.4pq9r9o93w.wasm"
    },
    {
      "hash": "sha256-6Mwurt7Z/qM2RAm1+NkjIUj5mn5BR45i4UJcCya63/Q=",
      "url": "_framework/System.Globalization.Calendars.okoam7mqn5.wasm"
    },
    {
      "hash": "sha256-Elz5NVivQTkKqHIJNreeVbtXs/2KKCUtNFIQuq//uLk=",
      "url": "_framework/System.Globalization.Extensions.i4rrqkn8ac.wasm"
    },
    {
      "hash": "sha256-1YqB96PKOgkYkalUR3wQlu3uogdQeWH5xXEGCQNO4JY=",
      "url": "_framework/System.IO.Compression.Brotli.d2ow5hc679.wasm"
    },
    {
      "hash": "sha256-pIIx6sGpg7lIMoD6XsSXh5e98RD4UR6PeGUU72JTulw=",
      "url": "_framework/System.IO.Compression.FileSystem.sq6287vix9.wasm"
    },
    {
      "hash": "sha256-txldHQvXq5/AojGKBcj/np3Rd4hnjTP76a8Kk+HEdz4=",
      "url": "_framework/System.IO.Compression.ZipFile.9oa5tdl9t1.wasm"
    },
    {
      "hash": "sha256-v7ExXK3+fRhJriLrbgJ2Q/cNQtr/mXv13NM5Kjr6T1k=",
      "url": "_framework/System.IO.Compression.rhgxgko2h5.wasm"
    },
    {
      "hash": "sha256-jCSXPSlhZWCMEYHmLF1W7N456nSgDlUnEsT9fE5EE9Q=",
      "url": "_framework/System.IO.FileSystem.AccessControl.8n7zqskxkd.wasm"
    },
    {
      "hash": "sha256-ecW2cFor/WKYdKGEZvCFGfDCusU9NtLSYW7mJwiMcO8=",
      "url": "_framework/System.IO.FileSystem.DriveInfo.7wstvlx8jl.wasm"
    },
    {
      "hash": "sha256-lGT0V7htPr7m6SfkPw9iwweJxFdQcwv8xltr+sPCzL0=",
      "url": "_framework/System.IO.FileSystem.Primitives.0zgy5v1s7p.wasm"
    },
    {
      "hash": "sha256-F17LlxWY1e1NnAHYhcVL9f5AE5Yh82YzUW8sYwuFs2w=",
      "url": "_framework/System.IO.FileSystem.Watcher.vuo9kdp4kd.wasm"
    },
    {
      "hash": "sha256-TqQkSx+sVMYnvMmbKq69N1yKO5pwXIIe/bkMhUgtHVk=",
      "url": "_framework/System.IO.FileSystem.a1ices0sc0.wasm"
    },
    {
      "hash": "sha256-JLLsEKKgpcxE3qUIMRKSYr5jf6lYcBJ/yoTCecMl6Ps=",
      "url": "_framework/System.IO.IsolatedStorage.gt0sn2slls.wasm"
    },
    {
      "hash": "sha256-htN378GjoT41MeTWs3nktLVLl5Dh021QOEzIDcnf4qE=",
      "url": "_framework/System.IO.MemoryMappedFiles.ihhgfevrz0.wasm"
    },
    {
      "hash": "sha256-mx0lZ6Lnd90bygi94MEHzoTQGPr7b1cInTdaAOneHiQ=",
      "url": "_framework/System.IO.Pipelines.vbnatvfacc.wasm"
    },
    {
      "hash": "sha256-/negGD8sNePBg0Kh+AHmzGqJBZcW5nAVi4y9rKaYLI4=",
      "url": "_framework/System.IO.Pipes.AccessControl.ywuu8iws4m.wasm"
    },
    {
      "hash": "sha256-iOD1MaLyysmn78ly0F04kwJdd2Pnwc9oz4CaUX63Hn8=",
      "url": "_framework/System.IO.Pipes.war1zb99zm.wasm"
    },
    {
      "hash": "sha256-tQYcNV5Kya71rWM2tbP+UCYvmwwbj5J10lSBXMChNmw=",
      "url": "_framework/System.IO.UnmanagedMemoryStream.jybv7hm02i.wasm"
    },
    {
      "hash": "sha256-2J0+n3XQkmWVcjhUnygaQUkAWGsFrCGc4q8NwvBbqXI=",
      "url": "_framework/System.IO.o4s3p2b0vt.wasm"
    },
    {
      "hash": "sha256-ay5ZQ8PHEUVWJdcCv/NrSw8QUTNKQlbtJ15E8LucrqU=",
      "url": "_framework/System.IdentityModel.Tokens.Jwt.zmzgmkn8sr.wasm"
    },
    {
      "hash": "sha256-460+wCtndATCs2lJFV80KBzZLZkyZbVPpQUZ8SXTW3U=",
      "url": "_framework/System.Linq.AsyncEnumerable.x3hu86km4d.wasm"
    },
    {
      "hash": "sha256-ihpJxLRbuKEL7k+f5QqPULDqw1yT2PS8n1Bj7kz6iPM=",
      "url": "_framework/System.Linq.Expressions.y6l58qfi1k.wasm"
    },
    {
      "hash": "sha256-GoizwKC+IoT0d/eDcQJqFYrA1h6AGU5t+YNaj6W50Cc=",
      "url": "_framework/System.Linq.Parallel.avc3ofe20h.wasm"
    },
    {
      "hash": "sha256-GKuL165Je6MAMPm82Xj2tGnUdoDWeqPpEQllj2IeM04=",
      "url": "_framework/System.Linq.Queryable.8su1tnihhz.wasm"
    },
    {
      "hash": "sha256-IwCw5ws0vXDTYk/VhCGNLytATpyNtOw07Gowc6MWQqs=",
      "url": "_framework/System.Linq.dghe007p0m.wasm"
    },
    {
      "hash": "sha256-5VnLBsQ2uFhmAyGuKGIltXN/VNAG8iQuzS2hPYpnX2Y=",
      "url": "_framework/System.Memory.588xedxy5a.wasm"
    },
    {
      "hash": "sha256-z01TQ7bJ7v70en+RgIE0OYdjKFomCXQTy9ArvMj2/wo=",
      "url": "_framework/System.Net.Http.57f5avnxib.wasm"
    },
    {
      "hash": "sha256-syZ9OpqQElS3kprFS7ez+sweXRTTyMDwMxJR3w1YSFo=",
      "url": "_framework/System.Net.Http.Json.5qm1oyxvyh.wasm"
    },
    {
      "hash": "sha256-SpEOjh/Ac0APXxcoBHAMA41Iy7J+y9urLlYz34kRLpk=",
      "url": "_framework/System.Net.HttpListener.urm8gfgnq3.wasm"
    },
    {
      "hash": "sha256-hGu5RH44Zx+KTFb2P7BhnD+korzXXOEa2xAYn1ruqR8=",
      "url": "_framework/System.Net.Mail.cgv1zf2uj2.wasm"
    },
    {
      "hash": "sha256-vnV7ogVECYzqn6DNevp7umiR3GGpqtTuhCfozuSFn0I=",
      "url": "_framework/System.Net.NameResolution.icwur878un.wasm"
    },
    {
      "hash": "sha256-FR4qRWgc9Pne0NZW+GI+IIQKRQkiJOkShLqu/KvOnf0=",
      "url": "_framework/System.Net.NetworkInformation.fvsj1ymwx0.wasm"
    },
    {
      "hash": "sha256-UW2rIqrtKRzousZW2F5nBCaBBwvDX3PW6QyR+ovnBGg=",
      "url": "_framework/System.Net.Ping.nixsq41c9a.wasm"
    },
    {
      "hash": "sha256-T6A4jMSZ9r3DZ6mSyYFovM2dSQMkCeHXZK/M20FYf1o=",
      "url": "_framework/System.Net.Primitives.9a0d5yreav.wasm"
    },
    {
      "hash": "sha256-gyc07ScBj9jCRpw2XXk6F0hxZ/9i5Ey1ZdiuWV1Gaw0=",
      "url": "_framework/System.Net.Quic.5at1qtuzp3.wasm"
    },
    {
      "hash": "sha256-cgiRx3WwyCsvJcTLyXUVhxpSRtBUaghD2v7UqCZzB1A=",
      "url": "_framework/System.Net.Requests.qqzugy2ce8.wasm"
    },
    {
      "hash": "sha256-BgjBIUJ6DDb/99Dx9CXebxnh9n+7qI3FpBXyqssGZgE=",
      "url": "_framework/System.Net.Security.26ik76io06.wasm"
    },
    {
      "hash": "sha256-jUUcOnECTcVnuN1q8RlBgsk74CATFIjYm9/jVb5Pmes=",
      "url": "_framework/System.Net.ServerSentEvents.5ux9mfotfn.wasm"
    },
    {
      "hash": "sha256-vOFqT0Wd42jdsUKqT50aGm6vf1Bb+MOkmMRRXXWSb3o=",
      "url": "_framework/System.Net.ServicePoint.8nsxn6s8cf.wasm"
    },
    {
      "hash": "sha256-wOAhxrXlPK+18C4vWHxJD16y6Wm/XE8wK/fEv85Tz3o=",
      "url": "_framework/System.Net.Sockets.gwr80k9ahj.wasm"
    },
    {
      "hash": "sha256-Hs5shsIqWQgN888mvNfOAVSeEwXFmcS2MidGSfnIKYU=",
      "url": "_framework/System.Net.WebClient.2z30y6k9kl.wasm"
    },
    {
      "hash": "sha256-GnbZuP+fILW8x81c+z5BuPA7vXj+sZ2K6N/OHyriWd8=",
      "url": "_framework/System.Net.WebHeaderCollection.ua6ocq28lq.wasm"
    },
    {
      "hash": "sha256-pr48EhQZyKsR4Yww7EyLAux5YatHR3TOaZqcjo4bRvE=",
      "url": "_framework/System.Net.WebProxy.uqybiqsyw6.wasm"
    },
    {
      "hash": "sha256-ZTVAReHozcyokPiMDZm3JTcLet4FEjLSFaHXAXlcJxA=",
      "url": "_framework/System.Net.WebSockets.Client.3254c7lu7w.wasm"
    },
    {
      "hash": "sha256-EatXDAg7M1/oNrXVRxADRX1umYaD0Ihv2d9oOfR1jHs=",
      "url": "_framework/System.Net.WebSockets.vko20fh3g3.wasm"
    },
    {
      "hash": "sha256-7wxmC7eXxO4EieYuLrSQYZziHcxo/xKIJQOmiceIxfs=",
      "url": "_framework/System.Net.z7li96dyub.wasm"
    },
    {
      "hash": "sha256-NFt8YebdKg/ke5VXqbgfQIdJh1zLaPQUbVowAI623Xs=",
      "url": "_framework/System.Numerics.855j443jdz.wasm"
    },
    {
      "hash": "sha256-tpcjjFLFgRY7xo1kiy8ejkhw0qxi77w3APs6mlWtLqk=",
      "url": "_framework/System.Numerics.Vectors.y1n4un3uik.wasm"
    },
    {
      "hash": "sha256-fy2zswxHhWkN5JIq65ws6Qt96lZ1RdlFkSzYNDou3Bo=",
      "url": "_framework/System.ObjectModel.3fm8unj13q.wasm"
    },
    {
      "hash": "sha256-NqJOEEPGc1ryQiRONyZ5eX+uGHNRrvYkzRwUU18qe54=",
      "url": "_framework/System.Private.CoreLib.qw7jna5etr.wasm"
    },
    {
      "hash": "sha256-HEWG/2E5ebhHNJ5Ad+jEBU256AfSHsS4z/XyXcAYroM=",
      "url": "_framework/System.Private.DataContractSerialization.ket5dpzngd.wasm"
    },
    {
      "hash": "sha256-2YW3+Ct/XDlJA/KLt1IfaSX2UekWGcLeUi4JyL/gYGA=",
      "url": "_framework/System.Private.Uri.l55n8xe8ey.wasm"
    },
    {
      "hash": "sha256-PaoT/f5PzENctAnsr8UG1Y0rDc0kAtp4n+xu4DuZwEI=",
      "url": "_framework/System.Private.Xml.Linq.5ivru5c0x1.wasm"
    },
    {
      "hash": "sha256-freYMpeef6fU1YwB5Jglh1z2VW39fnR4ASw0GGeZN6M=",
      "url": "_framework/System.Private.Xml.yooek47hqz.wasm"
    },
    {
      "hash": "sha256-fAE93ivkuWSanEyhGTCzaRKbRHjJDHJAn/b9febuou4=",
      "url": "_framework/System.Reflection.DispatchProxy.wlbv2c89xk.wasm"
    },
    {
      "hash": "sha256-fBwEivu+tREeIOJJmshSOZnHp/dOB4WsHMIEwMimVow=",
      "url": "_framework/System.Reflection.Emit.ILGeneration.0rrknf0d7q.wasm"
    },
    {
      "hash": "sha256-sV6u/TxyELC+pefCtqUuOiMjWavK9Wv7zFj7SvXFtMc=",
      "url": "_framework/System.Reflection.Emit.Lightweight.j3dwz5itwq.wasm"
    },
    {
      "hash": "sha256-hkAJZB6/FqE4iC1hL8PsW29/Z7wM+UdzCzXwAIoITKU=",
      "url": "_framework/System.Reflection.Emit.qr26lus3fn.wasm"
    },
    {
      "hash": "sha256-ZzFoFBSDyBMMAcgUNkA0SvrpGTWQayc5f2vOmiEEhpc=",
      "url": "_framework/System.Reflection.Extensions.j5ef89rrpk.wasm"
    },
    {
      "hash": "sha256-0ZjzHTuQl4xNIQAlXxWWCvxRzlolPb7u+GFwzQ37G9I=",
      "url": "_framework/System.Reflection.Metadata.1syjaqjddv.wasm"
    },
    {
      "hash": "sha256-V6fZEVLpoWvKFFb9k7n1fSoWeMKRy1my85j6HUx51vE=",
      "url": "_framework/System.Reflection.Primitives.lxz73xefgr.wasm"
    },
    {
      "hash": "sha256-/ct9T1oknQ3TDYfyiiDL+9M6nTOyN8KPXJ8VpjFi7Hs=",
      "url": "_framework/System.Reflection.TypeExtensions.v53w8pdu58.wasm"
    },
    {
      "hash": "sha256-GFbjPmfUkKwpDwoSo9ocRkSh+/Lze35e0T+yPmWEyx8=",
      "url": "_framework/System.Reflection.c3iqc3clxz.wasm"
    },
    {
      "hash": "sha256-xlo4EopKiJbCMIr7Ey8K24ejIsDD059Ics/6+LnkdE0=",
      "url": "_framework/System.Resources.Reader.i2yn1y7nud.wasm"
    },
    {
      "hash": "sha256-tkn4hXlvusBhdfgSoIMY9M/2anUDJfzvpR7WD6+6PJg=",
      "url": "_framework/System.Resources.ResourceManager.qrxfxc4507.wasm"
    },
    {
      "hash": "sha256-NsDhbh1gHJDilgdQ9KpCsPb0zdCcyFKOhYEIe92VmWU=",
      "url": "_framework/System.Resources.Writer.as5y27nn2h.wasm"
    },
    {
      "hash": "sha256-8DiTWZHty5ftLwVrAvKk0+GaUaLeO/8OP0y0FEdbz9I=",
      "url": "_framework/System.Runtime.CompilerServices.Unsafe.w8la5ypnnp.wasm"
    },
    {
      "hash": "sha256-ffeGQ9X3EiKFBY9545TUOrXv2lRNMavkaV6tjRibnWk=",
      "url": "_framework/System.Runtime.CompilerServices.VisualC.vl7kxd1eod.wasm"
    },
    {
      "hash": "sha256-nEqy3SDjwxJIx1/rXq9mergvJSepcbYmzebg0MkQ8tI=",
      "url": "_framework/System.Runtime.Extensions.ohqexbct3w.wasm"
    },
    {
      "hash": "sha256-WhhJZvBneqWPPYoKMR8ha72pZoAcs5+yOtQIuGSiID8=",
      "url": "_framework/System.Runtime.Handles.msacid496p.wasm"
    },
    {
      "hash": "sha256-j+w+UKu0Gc9+OxdEZzcvU5335iO6FGXzOGZ8YBoLLSw=",
      "url": "_framework/System.Runtime.InteropServices.JavaScript.foigmtgjzq.wasm"
    },
    {
      "hash": "sha256-+tM4fUk6FgdYImRDUDvdxjS/CUY/KCGp3XDgydp7Jrg=",
      "url": "_framework/System.Runtime.InteropServices.RuntimeInformation.e3cbqagcoy.wasm"
    },
    {
      "hash": "sha256-E7bKIok3I980HYP5oLgMfjp0yBUe1L0TZoijyIyU7sU=",
      "url": "_framework/System.Runtime.InteropServices.rmi7wrfwcz.wasm"
    },
    {
      "hash": "sha256-Z5srRWKzoQes8PQtTy59YmPNEicp3WvO31NsaQ1FJM0=",
      "url": "_framework/System.Runtime.Intrinsics.1a3cd3zuob.wasm"
    },
    {
      "hash": "sha256-6s0efDI0D7X/cNiXHK/IYmhMXseRR5Fpv2sPg2RtGZE=",
      "url": "_framework/System.Runtime.Loader.ytyzjtlfyy.wasm"
    },
    {
      "hash": "sha256-A9B/M7AgOfeb0ct087rT54CcYNmsbVX1ovJAndAUFeQ=",
      "url": "_framework/System.Runtime.Numerics.1j1dzlfm3y.wasm"
    },
    {
      "hash": "sha256-jsp4j3r2X/XMf+mMljsoiOjIQWuTdj02nXXCeZMtGFQ=",
      "url": "_framework/System.Runtime.Serialization.Formatters.63sl05sz2a.wasm"
    },
    {
      "hash": "sha256-9v8mFscX6z6vnrieUVCJ31ksJkifdR1q22q7aRbr1hQ=",
      "url": "_framework/System.Runtime.Serialization.Json.un36wute9j.wasm"
    },
    {
      "hash": "sha256-2QBvhM0jyjlzooTbY7xLNUlJgnLl6U453pK42aXw4sY=",
      "url": "_framework/System.Runtime.Serialization.Primitives.xaxxmx62hr.wasm"
    },
    {
      "hash": "sha256-KikViZm9CG9Vk2kIgv7TCzq0GXJZqJTDktf2vzS6NpY=",
      "url": "_framework/System.Runtime.Serialization.Xml.yed5yhd91g.wasm"
    },
    {
      "hash": "sha256-FTH8XiASRvFRvRKOFcoGFbrQ42aHN4k1zaiHsukWCeg=",
      "url": "_framework/System.Runtime.Serialization.xlg8rg3fxp.wasm"
    },
    {
      "hash": "sha256-601Jnf7DZ40RKeHmKkvIGdzLOUsFL4Sq8e+gfq7EJNA=",
      "url": "_framework/System.Runtime.vvbv862woi.wasm"
    },
    {
      "hash": "sha256-DLmaXOUnj8gmVPzOl8yHlQVaBrlrDkb5L+rqN/e9GFs=",
      "url": "_framework/System.Security.0z6z3qehfj.wasm"
    },
    {
      "hash": "sha256-JKEARLSCJVwW2HJn16iNVeHoDUcJQKzqYasnkdjsj4I=",
      "url": "_framework/System.Security.AccessControl.cypvwbqhbn.wasm"
    },
    {
      "hash": "sha256-D/n8VHRRAlwIODqBph+Pf63IjbR8xzlDfYLawlNjFNk=",
      "url": "_framework/System.Security.Claims.nug3xsxrdh.wasm"
    },
    {
      "hash": "sha256-2na9RztTgjHAh6E1RpP7PHlgqyH5qhQjdYSlDHe0/v8=",
      "url": "_framework/System.Security.Cryptography.29e01kxrq6.wasm"
    },
    {
      "hash": "sha256-PuRVO47I3VP6idl03BBl2UGUNVi3QoXkRZI/3+AXezM=",
      "url": "_framework/System.Security.Cryptography.Algorithms.67sgtjo5cg.wasm"
    },
    {
      "hash": "sha256-RZke8z4EQL8SimK31P7x56viyOy8pc/tN3A4soyFaXE=",
      "url": "_framework/System.Security.Cryptography.Cng.xh8xs1r8y9.wasm"
    },
    {
      "hash": "sha256-TkPFLo0OiEDjC7H9E2H8wlPHxZnEKSIl8XGCvovrp+w=",
      "url": "_framework/System.Security.Cryptography.Csp.6ftjhw3l8h.wasm"
    },
    {
      "hash": "sha256-JKweSKt1M01rh4E2jHLBWuBm2p+iFp8sGFDiarq13OE=",
      "url": "_framework/System.Security.Cryptography.Encoding.8jr3ugahs7.wasm"
    },
    {
      "hash": "sha256-ER1jBJE4hLtydKSDnep5OKeUIpY/VWiViGZPRHO7zPo=",
      "url": "_framework/System.Security.Cryptography.OpenSsl.x0z78unzo3.wasm"
    },
    {
      "hash": "sha256-TzLEcHu0G8ee8WaRVPDzF9idjwX/VjK57tTmD7vCWK4=",
      "url": "_framework/System.Security.Cryptography.Primitives.txvslu1vx1.wasm"
    },
    {
      "hash": "sha256-uDO0TrlPdRJH1Rige/hapBrPyjPP3VJAfEGkKM83c4c=",
      "url": "_framework/System.Security.Cryptography.X509Certificates.os75ly4xag.wasm"
    },
    {
      "hash": "sha256-k/Bopmf7AxV/rJPB6zJ1U2bq4p4QbX2v1TYZ7ebbPYQ=",
      "url": "_framework/System.Security.Principal.7nxpmtd1co.wasm"
    },
    {
      "hash": "sha256-ZON5ZhKMPOqX9XA5c9enHhkH5wns3NBrp31X2GOiB8g=",
      "url": "_framework/System.Security.Principal.Windows.otv2bpu9cg.wasm"
    },
    {
      "hash": "sha256-QEqW6+0GDJAeAm1J/tL8f+jhjQDA0Go01q7DaBxeuxU=",
      "url": "_framework/System.Security.SecureString.439tzhhybn.wasm"
    },
    {
      "hash": "sha256-SA6QjxDYIhhxl5e8YR8bbaGOxfEhtdTzFvPjgV83KnU=",
      "url": "_framework/System.ServiceModel.Web.w22rvbwpzp.wasm"
    },
    {
      "hash": "sha256-k9yqPh57nhwvq8fNxhOxfX5pbdyQwQOoTJLiby1aATQ=",
      "url": "_framework/System.ServiceProcess.7jyvkehqsc.wasm"
    },
    {
      "hash": "sha256-MfOpQrXkc2OrR+whoH8eAuDmtGoB69B0llh5AOlh2Pg=",
      "url": "_framework/System.Text.Encoding.3vrnoet1y1.wasm"
    },
    {
      "hash": "sha256-bKfFdtAfGy6c3aMrNCbobEz7dEuFMoLkf6k0QM4Bf1o=",
      "url": "_framework/System.Text.Encoding.CodePages.k0gizhdiba.wasm"
    },
    {
      "hash": "sha256-9rMn6NPjMiBzmGh8/h/Bz45K4koS97O1vZ7Z0QUtZZE=",
      "url": "_framework/System.Text.Encoding.Extensions.eqwxk3d1le.wasm"
    },
    {
      "hash": "sha256-owL5cUGn1SH0f+nWMT2v3uW8EsLqrgXlLGLDAWa5MLI=",
      "url": "_framework/System.Text.Encodings.Web.9h3vqstrfu.wasm"
    },
    {
      "hash": "sha256-2aD/r5N2hpi6wcFOdC1UiwrgyMKeqkB63qhWe+yBFPc=",
      "url": "_framework/System.Text.Json.zxq3or1p48.wasm"
    },
    {
      "hash": "sha256-mZPmiN9jNosXwdGgQ1Rl/tdXuAISwUyoGZi/hZZb8IU=",
      "url": "_framework/System.Text.RegularExpressions.129blvw20n.wasm"
    },
    {
      "hash": "sha256-z/omVAVC0GL2bp0b01MADAClMOFzwJJ5H3eiRi8d1nM=",
      "url": "_framework/System.Threading.53g31wzhbf.wasm"
    },
    {
      "hash": "sha256-FgfhxREFUtvdC/60lhXZgM/E1+O6BWIwaP9cOlop6wE=",
      "url": "_framework/System.Threading.AccessControl.qcuh5cf2g5.wasm"
    },
    {
      "hash": "sha256-VWvw17EgRCgCqxr/5GP/7gMaGz6BiD7plcJzEhRi9HM=",
      "url": "_framework/System.Threading.Channels.93ewwvqv6d.wasm"
    },
    {
      "hash": "sha256-K4mb+zcfBo1RdZw9hVnMlmn+V25Z9wCRuZ9t0E6gzPI=",
      "url": "_framework/System.Threading.Overlapped.r0ttlv8fwx.wasm"
    },
    {
      "hash": "sha256-/+bVv9uy1YnJqmEs7/k/MHW+MdvugaOvuSZiXrZcLFU=",
      "url": "_framework/System.Threading.Tasks.9y3wtgkupw.wasm"
    },
    {
      "hash": "sha256-WUpWT0kUUaiAtahsdlMpiv3C3tFVncRE+KdEfHWl5Xk=",
      "url": "_framework/System.Threading.Tasks.Dataflow.v2c20367ml.wasm"
    },
    {
      "hash": "sha256-aXIoETHOA/noVMD/XhGHAl3JDeyWBL9HBeC1P6Oie3I=",
      "url": "_framework/System.Threading.Tasks.Extensions.3hj0r8lznm.wasm"
    },
    {
      "hash": "sha256-grDZAlJNpdditU+aDQzAtjYyHtNj2BId+pSAzESSEl4=",
      "url": "_framework/System.Threading.Tasks.Parallel.ayr8d1m559.wasm"
    },
    {
      "hash": "sha256-atwtrp76mgREzQqxukT2JdtvAlJtK+CH3ufJ+YzAd5U=",
      "url": "_framework/System.Threading.Thread.unpebuo3i9.wasm"
    },
    {
      "hash": "sha256-z41Xjc4bHfEDpJAhieRobcm1Xno3XylUl7E2F1RzJ00=",
      "url": "_framework/System.Threading.ThreadPool.bh6gp8z466.wasm"
    },
    {
      "hash": "sha256-NOGaCVdktjeU4GNBRctFphvR2eaIvcFOusevjMbEzC4=",
      "url": "_framework/System.Threading.Timer.c8u3jkyen2.wasm"
    },
    {
      "hash": "sha256-7hMdJQvHwUoKSb/sWRyZXydXUfq88NRbpuiuBT/5K64=",
      "url": "_framework/System.Transactions.Local.uobvv2wgx8.wasm"
    },
    {
      "hash": "sha256-ZVDuJFhcLs2jfcIA/w8nv9EhZkBJit3oVr+BR4BHbNA=",
      "url": "_framework/System.Transactions.nxeoadzm1f.wasm"
    },
    {
      "hash": "sha256-c75CdCuK+BJBsdOPgohc65I6jIm3deFlS43lIotMimk=",
      "url": "_framework/System.ValueTuple.r6owwrlzt7.wasm"
    },
    {
      "hash": "sha256-jMxEWiikPGKAPdYUrf0Grj+8YCC8xG/WAMtbOP4i7DI=",
      "url": "_framework/System.Web.HttpUtility.8vlz6hzctr.wasm"
    },
    {
      "hash": "sha256-5Z30bO02sZNciGoFtCslbZ1Vi96Oe7dlaESKKsqcRVE=",
      "url": "_framework/System.Web.hp5gplb5gn.wasm"
    },
    {
      "hash": "sha256-MK4uPQz5EVSwxiUXIdP91BnfN5ojacqiI5GA86yRqdI=",
      "url": "_framework/System.Windows.g86pyps5t9.wasm"
    },
    {
      "hash": "sha256-u4HyIU3do27l2nuCH4BsMjPAieGdPZB4MuubpjiI8i4=",
      "url": "_framework/System.Xml.Linq.htamaluwqy.wasm"
    },
    {
      "hash": "sha256-n74w3KwVjDzCs/RdWqgWNFY1/3SuN+6D8tnxr2iJQcI=",
      "url": "_framework/System.Xml.ReaderWriter.lvvcxtot1v.wasm"
    },
    {
      "hash": "sha256-59IVg9VsmB6FlTaqROrZNGLamzmFW8NPpACsnkBLh9A=",
      "url": "_framework/System.Xml.Serialization.h2wjs2ywtx.wasm"
    },
    {
      "hash": "sha256-HcNqaSyulOmhCG7YnOxxRTQuR0fW6uDkhmhEMw2r7o8=",
      "url": "_framework/System.Xml.XDocument.r6j7sl9tah.wasm"
    },
    {
      "hash": "sha256-dVaYRI14iA8Dxkphyl7xskC8c7e37Il91eANt8NE83A=",
      "url": "_framework/System.Xml.XPath.XDocument.1l4l8dvoxa.wasm"
    },
    {
      "hash": "sha256-bkIp85FjNUVd7Wb4w8TNkm8vQZoT+dsl4GCwLC6hjVE=",
      "url": "_framework/System.Xml.XPath.ybwz834ao8.wasm"
    },
    {
      "hash": "sha256-jV9J/Iu4smJpxqdL9JO2DeMV89EokbdfhXEBpDikuHE=",
      "url": "_framework/System.Xml.XmlDocument.5aywymfu34.wasm"
    },
    {
      "hash": "sha256-SNWvbN9fZZMmIEcPCb0mvPSQdT88ZaeRi9BEDoMQPN4=",
      "url": "_framework/System.Xml.XmlSerializer.84364zdnpr.wasm"
    },
    {
      "hash": "sha256-DoroG7ocOSqjp5a0dFSQ2CBexP5UL6dYLbgEblFYMRw=",
      "url": "_framework/System.Xml.exkkf0ue13.wasm"
    },
    {
      "hash": "sha256-g4P8jeQxySC/JceIpYQYuU6Hv+Vlw6QG8VspPBa8fU4=",
      "url": "_framework/WindowsBase.1bna4dlnz5.wasm"
    },
    {
      "hash": "sha256-lDXsDYFgm62F+YUvxES7IOTCXYpiHpU3uR45YdC6mq4=",
      "url": "_framework/blazor.webassembly.js"
    },
    {
      "hash": "sha256-n4OdLP21kMuXeGGhbVO75UEBSX9ZKKVVjP7oiohMZeg=",
      "url": "_framework/dotnet.js"
    },
    {
      "hash": "sha256-KExoq8VPhmB8YF9AMrBgJl5Djc0GcUCDRZamr2XfXDY=",
      "url": "_framework/dotnet.js.map"
    },
    {
      "hash": "sha256-jZddobLBM2C3lQhYQ61xSQJ/WqD3eQCO3RzoHGaOjx0=",
      "url": "_framework/dotnet.native.b6l13xorvf.js"
    },
    {
      "hash": "sha256-JTxXd17wbrHKV/375moHFUFc3a/ofVTPPqSTk6KwNj0=",
      "url": "_framework/dotnet.native.rw4kynp763.wasm"
    },
    {
      "hash": "sha256-syG9IXiHQCtzanA5XL22frAYJap423+MY37xDpB606c=",
      "url": "_framework/dotnet.runtime.js.map"
    },
    {
      "hash": "sha256-QbnqrZGHtGq7wudS17/AYEPpH9JkphrsyVllD6JHmds=",
      "url": "_framework/dotnet.runtime.v06hirbjsv.js"
    },
    {
      "hash": "sha256-SZLtQnRc0JkwqHab0VUVP7T3uBPSeYzxzDnpxPpUnHk=",
      "url": "_framework/icudt_CJK.tjcz0u77k5.dat"
    },
    {
      "hash": "sha256-8fItetYY8kQ0ww6oxwTLiT3oXlBwHKumbeP2pRF4yTc=",
      "url": "_framework/icudt_EFIGS.tptq2av103.dat"
    },
    {
      "hash": "sha256-L7sV7NEYP37/Qr2FPCePo5cJqRgTXRwGHuwF5Q+0Nfs=",
      "url": "_framework/icudt_no_CJK.lfu7j35m59.dat"
    },
    {
      "hash": "sha256-QZ5/Y+ezLvH8iwfmMJj2N3vLM7s/xDh5yEqepvTPRPE=",
      "url": "_framework/mscorlib.7ib23idm97.wasm"
    },
    {
      "hash": "sha256-SvqyxvD4F1LMOk45HiQ1ZMYR07zYGfKMaw2p6taAiHs=",
      "url": "_framework/netstandard.ajwk8nuaeb.wasm"
    },
    {
      "hash": "sha256-b8826O1IyDfWxerbhUGfSW8dsfM3CjciXHEyimAggPs=",
      "url": "css/app.css"
    },
    {
      "hash": "sha256-4mWsDy3aHl36ZbGt8zByK7Pvd4kRUoNgTYzRnwmPHwg=",
      "url": "favicon.png"
    },
    {
      "hash": "sha256-DbpQaq68ZSb5IoPosBErM1QWBfsbTxpJqhU0REi6wP4=",
      "url": "icon-192.png"
    },
    {
      "hash": "sha256-oEo6d+KqX5fjxTiZk/w9NB3Mi0+ycS5yLwCKwr4IkbA=",
      "url": "icon-512.png"
    },
    {
      "hash": "sha256-sz0gYf/lEKNYDjvnzx1d7FSf76FEq9TFvD2ju/bnMYg=",
      "url": "index.html"
    },
    {
      "hash": "sha256-Eg1IOjMTDw2QIaNk/ZbJtx++jFMiu3S+REw43ajWaic=",
      "url": "js/offline.js"
    },
    {
      "hash": "sha256-f4c8YV1qrr6RSiVYWMQT7R5W2OkT+iXmE5H69/uRvGQ=",
      "url": "lib/bootstrap/dist/css/bootstrap-grid.css"
    },
    {
      "hash": "sha256-xAT+n25FE5hvOjj2fG4YdOwr1bl4IlAJBNg6PbhLT2E=",
      "url": "lib/bootstrap/dist/css/bootstrap-grid.css.map"
    },
    {
      "hash": "sha256-hN2ttMG/K3wQlFrN3SbQ1YF4tIJHCE4oYP+QibT3vOY=",
      "url": "lib/bootstrap/dist/css/bootstrap-grid.min.css"
    },
    {
      "hash": "sha256-kgL+xwVmM8IOs15lnoHt9daR2LRMiBG/cYgUPcKQOY4=",
      "url": "lib/bootstrap/dist/css/bootstrap-grid.min.css.map"
    },
    {
      "hash": "sha256-M15fHTKfMK6cTars5c28PNhN6hD0qeUb3HPzOdoPwCc=",
      "url": "lib/bootstrap/dist/css/bootstrap-grid.rtl.css"
    },
    {
      "hash": "sha256-/siQUA8yX830j+cL4amKHY3yBtn3n8z3Eg+VZ15f90k=",
      "url": "lib/bootstrap/dist/css/bootstrap-grid.rtl.css.map"
    },
    {
      "hash": "sha256-+rGG3u63SMkHL80Ga42LAawPUj7i8vaR2Kuenqlta2E=",
      "url": "lib/bootstrap/dist/css/bootstrap-grid.rtl.min.css"
    },
    {
      "hash": "sha256-7GdOlw7U/wgyaeUtFmxPz5/MphdvVSPtVOOlTn9c33Q=",
      "url": "lib/bootstrap/dist/css/bootstrap-grid.rtl.min.css.map"
    },
    {
      "hash": "sha256-rjusxCRzKjztCcfgOVduAc3e3Z7KvimJGokJSeADNmE=",
      "url": "lib/bootstrap/dist/css/bootstrap-reboot.css"
    },
    {
      "hash": "sha256-RXJ/QZiBfHXoPtXR2EgC+bFo2pe3GtbZO722RtiLGzQ=",
      "url": "lib/bootstrap/dist/css/bootstrap-reboot.css.map"
    },
    {
      "hash": "sha256-y72bT5TKmFmfvw3bNEzPRNZa/8595xtseZIcBUV0PdM=",
      "url": "lib/bootstrap/dist/css/bootstrap-reboot.min.css"
    },
    {
      "hash": "sha256-0eqVT62kqRLJh9oTqLeIH4UnQskqVjib8hl2fXxl4lg=",
      "url": "lib/bootstrap/dist/css/bootstrap-reboot.min.css.map"
    },
    {
      "hash": "sha256-gRKIHVkBgnCPUs/hmZsXynZ9ZJpvsE77idtljDkrWGI=",
      "url": "lib/bootstrap/dist/css/bootstrap-reboot.rtl.css"
    },
    {
      "hash": "sha256-OoQVwh7Arp7bVoK2ZiTx2S//KrnPrSPzPZ93CqCMhe8=",
      "url": "lib/bootstrap/dist/css/bootstrap-reboot.rtl.css.map"
    },
    {
      "hash": "sha256-UkajePbMzGj8y73Imkd3dWWnLJr0v2CrBCLMrVMleP8=",
      "url": "lib/bootstrap/dist/css/bootstrap-reboot.rtl.min.css"
    },
    {
      "hash": "sha256-910zw+rMdcg0Ls48ATp65vEn8rd5HvPxOKm2x3/CBII=",
      "url": "lib/bootstrap/dist/css/bootstrap-reboot.rtl.min.css.map"
    },
    {
      "hash": "sha256-uIzOR4gILoNjCGNryIsWnkEGO3BSwRa/MLjr73tDodE=",
      "url": "lib/bootstrap/dist/css/bootstrap-utilities.css"
    },
    {
      "hash": "sha256-Nfjrc4Ur9Fv2oBEswQWIyBnNDP99q+LhL+z9553O0cY=",
      "url": "lib/bootstrap/dist/css/bootstrap-utilities.css.map"
    },
    {
      "hash": "sha256-ZBXbYF8OZrF1GDOLMLvW/zRPtx1RfeMDYj5D2Wb/9jo=",
      "url": "lib/bootstrap/dist/css/bootstrap-utilities.min.css"
    },
    {
      "hash": "sha256-rHDmip4JZzuaGOcSQ1QSQrIbG0Eb3Zja9whqSF1zYIU=",
      "url": "lib/bootstrap/dist/css/bootstrap-utilities.min.css.map"
    },
    {
      "hash": "sha256-MwFckg8YbY2WrveNQnXkfULkprYhFOq+t1BH92A7GsI=",
      "url": "lib/bootstrap/dist/css/bootstrap-utilities.rtl.css"
    },
    {
      "hash": "sha256-p0BVq5Ve/dohBIdfbrZsoQNu02JSsKh1g0wbyiQiUaU=",
      "url": "lib/bootstrap/dist/css/bootstrap-utilities.rtl.css.map"
    },
    {
      "hash": "sha256-7MYEMUFgHEc1CjrfAK/TlV30POxgoxXk2b+vAs/143U=",
      "url": "lib/bootstrap/dist/css/bootstrap-utilities.rtl.min.css"
    },
    {
      "hash": "sha256-o8XK32mcY/FfcOQ1D2HJvVuZ0YTXSURZDLXCK0fnQeA=",
      "url": "lib/bootstrap/dist/css/bootstrap-utilities.rtl.min.css.map"
    },
    {
      "hash": "sha256-CzmECrtXV8BSk/+8SG+Rw7Fr+3hCt2bS2bEkS4YD3PQ=",
      "url": "lib/bootstrap/dist/css/bootstrap.css"
    },
    {
      "hash": "sha256-KzNVR3p7UZGba94dnCtlc6jXjK5urSPiZ/eNnKTmDkw=",
      "url": "lib/bootstrap/dist/css/bootstrap.css.map"
    },
    {
      "hash": "sha256-sKIQRfQriISuQ9l/44b1zHfQniGXJhGonVtB2LlSuIs=",
      "url": "lib/bootstrap/dist/css/bootstrap.min.css"
    },
    {
      "hash": "sha256-8SM4U2NQpCLGTQLW5D/x3qSTwxVq2CP+GXYc3V1WwFs=",
      "url": "lib/bootstrap/dist/css/bootstrap.min.css.map"
    },
    {
      "hash": "sha256-/rceNUMI0RlFJugRzjua815bgXwawEJBGBPh4Vx3r38=",
      "url": "lib/bootstrap/dist/css/bootstrap.rtl.css"
    },
    {
      "hash": "sha256-3bYWUiiVYMZfv2wq5JnXIsHlQKgSKs/VcRivgjgZ1ho=",
      "url": "lib/bootstrap/dist/css/bootstrap.rtl.css.map"
    },
    {
      "hash": "sha256-rI1w2GDxZPCr77bpZIGQ8mUvMVtEr+gBtahl5RIPJpA=",
      "url": "lib/bootstrap/dist/css/bootstrap.rtl.min.css"
    },
    {
      "hash": "sha256-rTzXlnepcb/vgFAiB+U7ODQAfOlJLfM3gY6IU7eIANk=",
      "url": "lib/bootstrap/dist/css/bootstrap.rtl.min.css.map"
    },
    {
      "hash": "sha256-gR7NmqDcnlSIBNsf3p3DcKyJxcRdvSMp7pniI3QT/3Y=",
      "url": "lib/bootstrap/dist/js/bootstrap.bundle.js"
    },
    {
      "hash": "sha256-ADEXOfEUSkfFzqvEXJXbsbreZ3xy0ekmkkGLa/sOi6E=",
      "url": "lib/bootstrap/dist/js/bootstrap.bundle.js.map"
    },
    {
      "hash": "sha256-6zfk2L8R3wCgRbZzpkEi7UYC2bc6fYGIgFfNeqyOWnQ=",
      "url": "lib/bootstrap/dist/js/bootstrap.bundle.min.js"
    },
    {
      "hash": "sha256-BNd/F4Qb9/XaW+dQmPRe0fLDby7OTtEAscQDM8NEYk4=",
      "url": "lib/bootstrap/dist/js/bootstrap.bundle.min.js.map"
    },
    {
      "hash": "sha256-3uomEeumg3qJUE5P4N3kleojTGR+QpyPjPcORvyd6CE=",
      "url": "lib/bootstrap/dist/js/bootstrap.esm.js"
    },
    {
      "hash": "sha256-18dnhM3mfIc7+jiqyWcWiOlM484c3PScI/MOUkSFia8=",
      "url": "lib/bootstrap/dist/js/bootstrap.esm.js.map"
    },
    {
      "hash": "sha256-REjSeieVKd00nAKwd6dv7MMhuVKvKctPmLI4iDRs/cc=",
      "url": "lib/bootstrap/dist/js/bootstrap.esm.min.js"
    },
    {
      "hash": "sha256-qg29M9L0ub+gVWVoPryMeby6EdeAOakemc3clA+Ton4=",
      "url": "lib/bootstrap/dist/js/bootstrap.esm.min.js.map"
    },
    {
      "hash": "sha256-hhgn6ntO1fSzy4RUwzQeJ+96oyydQ1R39yXXwA349qY=",
      "url": "lib/bootstrap/dist/js/bootstrap.js"
    },
    {
      "hash": "sha256-JTtZaKPrZS15ryrBGdSkDG5Xh/u1j9w4Mt8zPv/de8I=",
      "url": "lib/bootstrap/dist/js/bootstrap.js.map"
    },
    {
      "hash": "sha256-aCTIqw9op0XQGYnNe1649V7fnihACD48OP3M8BP2xVM=",
      "url": "lib/bootstrap/dist/js/bootstrap.min.js"
    },
    {
      "hash": "sha256-De0sF9esziQNdfl0pAVTCpHrulCYvCjhgupkFEMbDCc=",
      "url": "lib/bootstrap/dist/js/bootstrap.min.js.map"
    },
    {
      "hash": "sha256-/F93WUBzjBJqM288qXqHr8OBjYVorakgTPXuafhbAZg=",
      "url": "manifest.json"
    },
    {
      "hash": "sha256-enKgCMkYmCpfEcmg6Annbmc40VZ/A6aYYSQjZfVn2cU=",
      "url": "sample-data/weather.json"
    }
  ]
};
