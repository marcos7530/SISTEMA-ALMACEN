self.assetsManifest = {
  "version": "1d/9GDG1",
  "assets": [
    {
      "hash": "sha256-zaLWJTjlmv1kP5sNx6NrZLD4d5wZ6nMBS9EH+62HBrk=",
      "url": "SistemaAlmacen.Client.styles.css"
    },
    {
      "hash": "sha256-itxgC9CUXgA0s57EK2bjpHhRABlrtO8ndt+ThYI7Lus=",
      "url": "_content/Microsoft.AspNetCore.Components.WebAssembly.Authentication/AuthenticationService.js"
    },
    {
      "hash": "sha256-gqucMFIuVF5boR/O3y/viDH5uyXJvkbdVMJrE9N+f00=",
      "url": "_framework/Microsoft.AspNetCore.Authorization.286cdd0mnj.wasm"
    },
    {
      "hash": "sha256-EbFyKid1qtnkJa2eCV02mgtXNS7mZhEY+6O2Cp0Jbwc=",
      "url": "_framework/Microsoft.AspNetCore.Components.Authorization.btlik35l51.wasm"
    },
    {
      "hash": "sha256-57t2ZKMLZfQOSsXNiNjXO8u1+yWfSHjzAr/To1NRW0k=",
      "url": "_framework/Microsoft.AspNetCore.Components.Forms.b7y73c8sd4.wasm"
    },
    {
      "hash": "sha256-yPMQHrHNo42HyIm6/bA/SIX61/7k22iPi8EbD6rK6xg=",
      "url": "_framework/Microsoft.AspNetCore.Components.Web.k10g806xum.wasm"
    },
    {
      "hash": "sha256-2v52XzJgJ6ozpnflImqfaMeXSfOJalZ2v7++eLcKRKg=",
      "url": "_framework/Microsoft.AspNetCore.Components.WebAssembly.Authentication.q8iyif4pxc.wasm"
    },
    {
      "hash": "sha256-niYTFW5FSoDH2+Ly40UDVo82CLSh45bcn60OHn3RKlc=",
      "url": "_framework/Microsoft.AspNetCore.Components.WebAssembly.au6z0bcsrs.wasm"
    },
    {
      "hash": "sha256-kHWRMmhRUqt14oDEP4wiUWv0I1Pdakmd7UimVDCMMAk=",
      "url": "_framework/Microsoft.AspNetCore.Components.o6y2k6vgc3.wasm"
    },
    {
      "hash": "sha256-KeYQjojYcSdQ7Cg7kPUrBLJ8FDUsYtcokMMYf9p5aoI=",
      "url": "_framework/Microsoft.AspNetCore.Metadata.59ibtucemk.wasm"
    },
    {
      "hash": "sha256-p2hOZdP04ox2bhy6/B/+fGJDWwWmx+S0Zgr8fTCeZgc=",
      "url": "_framework/Microsoft.Bcl.Cryptography.3pa69hqvhn.wasm"
    },
    {
      "hash": "sha256-psMoxmxraX+UqMuR6yuCJ2c/xLT3w20OO1JzVzNJ8qQ=",
      "url": "_framework/Microsoft.CSharp.mp8lhr6rez.wasm"
    },
    {
      "hash": "sha256-6uV0NjpPwFFRsf7cXNlSmekq8hPbgxe9oP4kmVJAFb8=",
      "url": "_framework/Microsoft.DotNet.HotReload.WebAssembly.Browser.ezrdz523gr.lib.module.js"
    },
    {
      "hash": "sha256-4h6PnLdgeWYG1/NUCACgpWvb2CVzuIToHpz/KguhvGg=",
      "url": "_framework/Microsoft.DotNet.HotReload.WebAssembly.Browser.mboztfuody.wasm"
    },
    {
      "hash": "sha256-qGEjY6VT2kt4ucUDReYxSt/AZBfFiBd5i7rkwP8WEFE=",
      "url": "_framework/Microsoft.Extensions.Configuration.Abstractions.gydskqrdmp.wasm"
    },
    {
      "hash": "sha256-hTi+lsmFyO+ohu81RCsWT31+ymlbM74tJEDpvEuN/qE=",
      "url": "_framework/Microsoft.Extensions.Configuration.Binder.jagglvwcdi.wasm"
    },
    {
      "hash": "sha256-6YRgll2ZRHI7X3l5jDKbbC6W5OGTmoAtT8EJqIHrhw0=",
      "url": "_framework/Microsoft.Extensions.Configuration.FileExtensions.lhv6s59pp1.wasm"
    },
    {
      "hash": "sha256-vEXfqN8qDFuhGvpgagVTNRsG1kmgCCceAIvCg/q5X3M=",
      "url": "_framework/Microsoft.Extensions.Configuration.Json.ovhjhq0url.wasm"
    },
    {
      "hash": "sha256-gAo2vNKc6IguqLYysEBH6sm0iSchu3oGbYQ3Aq5PtSM=",
      "url": "_framework/Microsoft.Extensions.Configuration.k3gsyevy27.wasm"
    },
    {
      "hash": "sha256-IIfEv8464evpIZhWH9CEVKytwJjFayCOQNxwFMSzewg=",
      "url": "_framework/Microsoft.Extensions.DependencyInjection.Abstractions.woum050g24.wasm"
    },
    {
      "hash": "sha256-jxt6IZ6EWYrltHD5SctKq9exI4IgXFWN8HHCGTGXWBA=",
      "url": "_framework/Microsoft.Extensions.DependencyInjection.dpa1450tku.wasm"
    },
    {
      "hash": "sha256-DT14V4vi9XUlFVFm3GmOzlxHBod9icve1tfVRr/16Dc=",
      "url": "_framework/Microsoft.Extensions.Diagnostics.1jey3rxiy8.wasm"
    },
    {
      "hash": "sha256-cRs5WmY9zg24WDKu0SNxfrTJSAWbn8nvTV4rqWaMxnw=",
      "url": "_framework/Microsoft.Extensions.Diagnostics.Abstractions.fkr8no9xuy.wasm"
    },
    {
      "hash": "sha256-RjswNfP4mBVN0iMFavEXD7bu4e4Sz7HV16ox6gIV4XU=",
      "url": "_framework/Microsoft.Extensions.FileProviders.Abstractions.21el9em0un.wasm"
    },
    {
      "hash": "sha256-ln/KyeKj5JrveXR6t0vxLSq821AqWW9mZ2qT/L+ES/k=",
      "url": "_framework/Microsoft.Extensions.FileProviders.Physical.6xc4mci3lw.wasm"
    },
    {
      "hash": "sha256-/omCzFRHNzhzfobQM7ycUMV5otX5+bIc/MagoIWI8/0=",
      "url": "_framework/Microsoft.Extensions.FileSystemGlobbing.qthbzihrxq.wasm"
    },
    {
      "hash": "sha256-6DzIf0hf+dxG6YyvkhCKRQplQmzo7XWuHH9ngbrlnDU=",
      "url": "_framework/Microsoft.Extensions.Logging.Abstractions.8weyptjtvc.wasm"
    },
    {
      "hash": "sha256-FEpTWBY+QUqwgBqB9uvDQO9eSFjq9S3rPQIaxVCVnaw=",
      "url": "_framework/Microsoft.Extensions.Logging.op9zaw9pvp.wasm"
    },
    {
      "hash": "sha256-oMBQFO2V/s0C8K6axybP94kUSUYD9fXaYKkooTHJQ4o=",
      "url": "_framework/Microsoft.Extensions.Options.ConfigurationExtensions.oic5e9iprm.wasm"
    },
    {
      "hash": "sha256-5zFrr6qDicK+jGfTglhuenZJfjcPRePRnMy7C6bhCZ0=",
      "url": "_framework/Microsoft.Extensions.Options.ldnbby568o.wasm"
    },
    {
      "hash": "sha256-n58JBASBWj2pbdb/VpoMiGC1xh+6OcVDccrku7x55Bg=",
      "url": "_framework/Microsoft.Extensions.Primitives.xoe0uq16op.wasm"
    },
    {
      "hash": "sha256-mJ4FsGe9wRo92tmuRPuLefQ+YQY5o+KXsjE6xYrF82A=",
      "url": "_framework/Microsoft.Extensions.Validation.gqyba4siw3.wasm"
    },
    {
      "hash": "sha256-2ZsMnds59dSHYhu5KzXaGE1gQeyjc+ZM5wi6+jj8M0E=",
      "url": "_framework/Microsoft.IdentityModel.Abstractions.bb9gljrr42.wasm"
    },
    {
      "hash": "sha256-8H4b4HSsImdM8Bs0G8mypE+oy6CM45G4GwYhKTj7UuI=",
      "url": "_framework/Microsoft.IdentityModel.JsonWebTokens.wsyb2e46l9.wasm"
    },
    {
      "hash": "sha256-SHi56dJlQX/HxVSiqpbxVaGPaR86C0FrfQg7Rqe3ies=",
      "url": "_framework/Microsoft.IdentityModel.Logging.o8o4sy1fv6.wasm"
    },
    {
      "hash": "sha256-nDKMrnv/osDdzy4YiT9q32K4Gwh/N4r03kBdq5X9xCo=",
      "url": "_framework/Microsoft.IdentityModel.Tokens.sut5rvh7q1.wasm"
    },
    {
      "hash": "sha256-9MGmvPvfhxv9bWwO5MaF9nzkGOhoslRrpxqSCctJetM=",
      "url": "_framework/Microsoft.JSInterop.WebAssembly.4mnezrwisk.wasm"
    },
    {
      "hash": "sha256-N1EMrB7k/3Mcs7qqnPDno0O+f2WfkwTpYOsFCf93ESU=",
      "url": "_framework/Microsoft.JSInterop.vei8iss1f3.wasm"
    },
    {
      "hash": "sha256-+AZA2Jpi7YedyPg/Z7OAvV4jcPpueAU4ylSeRvJDt80=",
      "url": "_framework/Microsoft.VisualBasic.0e5fchkecn.wasm"
    },
    {
      "hash": "sha256-veBhGyorrzdMHfiRDt/VovNG125rLLrL7enX5fvvfnE=",
      "url": "_framework/Microsoft.VisualBasic.Core.17wn27qal2.wasm"
    },
    {
      "hash": "sha256-UxlTjVzD23T3TLHwBAoQkPNd2pcDDBI/aV05iU6Dxwo=",
      "url": "_framework/Microsoft.Win32.Primitives.9d566sle9e.wasm"
    },
    {
      "hash": "sha256-Y+jj+a+2gTHHiYlyKc94wEH41wg3Vjrdd9KSP0crV6g=",
      "url": "_framework/Microsoft.Win32.Registry.52dy96yk8i.wasm"
    },
    {
      "hash": "sha256-LKOAjbnehjV8yBooT/JNWLtKIRhXUwEpRZQ9eCw1q1Q=",
      "url": "_framework/SistemaAlmacen.Client.csragu7d99.wasm"
    },
    {
      "hash": "sha256-oxPFtJ698kYoQeIWkms1V3Z8/lu/1odYkYgO9XWKoeo=",
      "url": "_framework/SistemaAlmacen.Client.jkodqjphgv.pdb"
    },
    {
      "hash": "sha256-LtWfAKJPaYKWDzI6eie33ZCX4dPIMAhDxC8QbBhh3tE=",
      "url": "_framework/SistemaAlmacen.Shared.aycp1b7o43.wasm"
    },
    {
      "hash": "sha256-N6JGmSWbRpAf43H+ozA2WUWG/PPeJa66UaG3YHMDfhA=",
      "url": "_framework/SistemaAlmacen.Shared.viltg4fopj.pdb"
    },
    {
      "hash": "sha256-M1WENJWA+3wr2NvHhLXh44JWWE4VVZag928GiVWbXG0=",
      "url": "_framework/System.AppContext.jwujeh069z.wasm"
    },
    {
      "hash": "sha256-QtI7D2XiD7NyCRDNW7Q5jPY5RrljqkJWOofJWLBpLOo=",
      "url": "_framework/System.Buffers.y0isk1x97h.wasm"
    },
    {
      "hash": "sha256-60VYOK8iVcWICnieMcztr96fSxmXaDwHYglhHVkfcWI=",
      "url": "_framework/System.Collections.Concurrent.x5koi7bzem.wasm"
    },
    {
      "hash": "sha256-lWe3YUN/Fc5uruvGWP/m8qaunD50OIQZlIigCznydZc=",
      "url": "_framework/System.Collections.Immutable.diwg7advch.wasm"
    },
    {
      "hash": "sha256-PH4kaa45WLnMxiRfMTzKCQ9u42dAwwdy99kptJLonnA=",
      "url": "_framework/System.Collections.NonGeneric.4089xs440e.wasm"
    },
    {
      "hash": "sha256-g9RG+K+iaKmrK6vAd+/MRgz68IbHHpSlRyOFIY27sUI=",
      "url": "_framework/System.Collections.Specialized.hj81u7zblb.wasm"
    },
    {
      "hash": "sha256-nQNshHg3oKyRQXw5zLw1fEm4B4SQKVyeH2F66wBEe3o=",
      "url": "_framework/System.Collections.nvrdeoknr1.wasm"
    },
    {
      "hash": "sha256-WuI5nXRLzegBvcDXd12p9roPYpi8jofCeEJ6v8s63+E=",
      "url": "_framework/System.ComponentModel.Annotations.yatcnfjeuk.wasm"
    },
    {
      "hash": "sha256-40rhAIB8j+yJ1YvnDmQ2rPIVWKNJO6UHLv/U4oSxlBI=",
      "url": "_framework/System.ComponentModel.DataAnnotations.led9l5awu3.wasm"
    },
    {
      "hash": "sha256-Oy0URE8zV5ayhb45ITWZbEnl6sGM9LatkYgbeAURRKM=",
      "url": "_framework/System.ComponentModel.EventBasedAsync.hpvp6cf4de.wasm"
    },
    {
      "hash": "sha256-W9/zGt2iJxheWHJRApI7G7Z0ckE5RfuWUz4Nnwxgbq4=",
      "url": "_framework/System.ComponentModel.Primitives.v7cajwpaqo.wasm"
    },
    {
      "hash": "sha256-QfHpIsM6pT5gYELaVBtPojDrl0GNwck46q4Mu933WCo=",
      "url": "_framework/System.ComponentModel.TypeConverter.xk1hnyt762.wasm"
    },
    {
      "hash": "sha256-aYhTsxu5l5DdQMIprD4ShbtwjTiJBH78I6wMQzBRnys=",
      "url": "_framework/System.ComponentModel.rrnda1lucx.wasm"
    },
    {
      "hash": "sha256-l2Yo9KFaXkgXpXguTZdnuTCytOYuPLjF8cZT0HHWwlg=",
      "url": "_framework/System.Configuration.bn9vghjcq8.wasm"
    },
    {
      "hash": "sha256-XKTYAvVqGguN3HteeYxjDwZqlFcFmIfpLOjNVjwXSNE=",
      "url": "_framework/System.Console.09ajpiafhz.wasm"
    },
    {
      "hash": "sha256-0C1e8tZ9+pmcU1MPfcf8D7NNcmR2pH8LdxsDMYrVHG0=",
      "url": "_framework/System.Core.wc649o5mw9.wasm"
    },
    {
      "hash": "sha256-bO/LPpxha6hSooSI6P+lazCSxTKXav6d+SSGI5xKoF8=",
      "url": "_framework/System.Data.Common.s4cowzd9a9.wasm"
    },
    {
      "hash": "sha256-QXrN9ZMMpWZeFTBu6yZlaw5lYx1+tUxEjhfaNEdHG4o=",
      "url": "_framework/System.Data.DataSetExtensions.5fm360ikxl.wasm"
    },
    {
      "hash": "sha256-ITg6VN5fCPuyFKC9ug/0vqXRoagnjGYhWj10y5heiTU=",
      "url": "_framework/System.Data.fsu4j4t4jw.wasm"
    },
    {
      "hash": "sha256-6+8hQYc91I+/Kqc5U6zCuNw2ConQevD1fmEvhSZFfoc=",
      "url": "_framework/System.Diagnostics.Contracts.p74re5oxzn.wasm"
    },
    {
      "hash": "sha256-kpDQTiMcfbO9nP5Mja6gzL4XTOp/9ixE1CD739WQlMo=",
      "url": "_framework/System.Diagnostics.Debug.622sixg49n.wasm"
    },
    {
      "hash": "sha256-HlxtCU+2k1YAqiabFqu5jOoUbMyV2ZEjNNlUEs/57NM=",
      "url": "_framework/System.Diagnostics.DiagnosticSource.2j35bc2g2b.wasm"
    },
    {
      "hash": "sha256-vZsGhIqd6ATctrY/LP4iZy0cDa+gN+Vzk8mA9ecl4as=",
      "url": "_framework/System.Diagnostics.FileVersionInfo.7n0wdvltaa.wasm"
    },
    {
      "hash": "sha256-QE2oJ8DjLG05OdC+fLmt+YhFiUEOSwyowwQ25oZCvTw=",
      "url": "_framework/System.Diagnostics.Process.8iffh49mew.wasm"
    },
    {
      "hash": "sha256-+Wsf/lB7CDI+7OUXetsTyE+lo4TYc/SAS1aMv1yniNM=",
      "url": "_framework/System.Diagnostics.StackTrace.1yz88vico8.wasm"
    },
    {
      "hash": "sha256-emPIv5g8xFmDr7oIZhZM/DTWGrb2Lggg7c+fjA99i5c=",
      "url": "_framework/System.Diagnostics.TextWriterTraceListener.ua8iuh2vhj.wasm"
    },
    {
      "hash": "sha256-2yLIVwYrPkQWk0Vxh+qS+KxNElAj+Z4UTmjJNv8uYNk=",
      "url": "_framework/System.Diagnostics.Tools.roy5445ugj.wasm"
    },
    {
      "hash": "sha256-AiYhBtmkwpOLWooLU6+KmJ0ySg6RY/ihjlCDgwQAT8E=",
      "url": "_framework/System.Diagnostics.TraceSource.6qx1ldzz7g.wasm"
    },
    {
      "hash": "sha256-S7GiSac0VcsB7GLrukNOyOx3UkyChvLMWC5lQW1nj0Q=",
      "url": "_framework/System.Diagnostics.Tracing.b4799zpaas.wasm"
    },
    {
      "hash": "sha256-OG93onlStdjfWzcLq3GSd7p2posHrpoBAptujpzu/ks=",
      "url": "_framework/System.Drawing.8gcjjqj0pu.wasm"
    },
    {
      "hash": "sha256-CiSvrtqNxb5mKdwQ7obhnTRpcvSS1e31SMHq2s6nrUc=",
      "url": "_framework/System.Drawing.Primitives.y2uveru2yk.wasm"
    },
    {
      "hash": "sha256-yL5qlZRpb8jHMNsapIzA7qNxs9DZvvAJx3/hCobHnpM=",
      "url": "_framework/System.Dynamic.Runtime.023zrvzh9x.wasm"
    },
    {
      "hash": "sha256-EYyyGznhWECmsc5FFdH6k26PlZIvsOFYMbRyQHlFCas=",
      "url": "_framework/System.Formats.Asn1.znpklkbgqv.wasm"
    },
    {
      "hash": "sha256-rcCcYOlxhVRG07eBm/7U2xhPK/cimbMV9phmtLI+B3o=",
      "url": "_framework/System.Formats.Tar.5yybjepfi2.wasm"
    },
    {
      "hash": "sha256-gb8ndHQ5edkgeIuuwJAZmpSvDSqmmSPYJbBgTzel/ps=",
      "url": "_framework/System.Globalization.Calendars.10g6hyjy3k.wasm"
    },
    {
      "hash": "sha256-vZkkaKr0ImZEgmnHPzo/msMMeEJQCqxSo2mTbfOzRzw=",
      "url": "_framework/System.Globalization.Extensions.hrinfrismg.wasm"
    },
    {
      "hash": "sha256-xiEtuDrnECbsdmpAPAp2VzmtL1v4IfFyExR96Fud89Y=",
      "url": "_framework/System.Globalization.uvs4rah8fk.wasm"
    },
    {
      "hash": "sha256-8KAD71Rcb1edG/x+Cx4wUA8/0cmGUGSciPma6jeXLXo=",
      "url": "_framework/System.IO.4j645gw40d.wasm"
    },
    {
      "hash": "sha256-Hpsq0zZpxCksmebhGlgCLpBfZlw6fRJn/pZ/QIvF8YQ=",
      "url": "_framework/System.IO.Compression.2z7vdt6tfb.wasm"
    },
    {
      "hash": "sha256-643QZL7ILdpDBnNsv23Zi0Cyzz5SoTjI9wGguHqusmM=",
      "url": "_framework/System.IO.Compression.Brotli.fv80xs79j3.wasm"
    },
    {
      "hash": "sha256-aOwoN3Ibisa2gVhxzBpktC2L4SEDgvRphJChLSaTA+Q=",
      "url": "_framework/System.IO.Compression.FileSystem.88jdddz3sw.wasm"
    },
    {
      "hash": "sha256-k7XPfNshrfMVIgaiuvKd377GtI7UYYnjDqJZyUkj+jc=",
      "url": "_framework/System.IO.Compression.ZipFile.jkn9avr4vo.wasm"
    },
    {
      "hash": "sha256-GjwWqllU9odjGWVpAjmupGx8/yiy5lsN2Not1a1soGg=",
      "url": "_framework/System.IO.FileSystem.AccessControl.yme0uhbu37.wasm"
    },
    {
      "hash": "sha256-/ojn2l2CNWusI2atVrRd8dbi7k4BARzLTJjRH6YgotM=",
      "url": "_framework/System.IO.FileSystem.DriveInfo.qas7wf73rs.wasm"
    },
    {
      "hash": "sha256-H8W0uho5WxWoH8hgJZEmNbdPpPYUgD8xkWHRSKx7MMc=",
      "url": "_framework/System.IO.FileSystem.Primitives.d1jmhkzu0e.wasm"
    },
    {
      "hash": "sha256-ucYunghHF7vLfVmQGmCY6aJsB2Kx9YKcaLYiWtXTNlY=",
      "url": "_framework/System.IO.FileSystem.Watcher.z570derp0d.wasm"
    },
    {
      "hash": "sha256-YA3yQ7lL5H0WBYDoElU5ZeVKxPgfltC+tweV2Ybbn/A=",
      "url": "_framework/System.IO.FileSystem.o6jtz51fup.wasm"
    },
    {
      "hash": "sha256-pxoMRl5qWZqgJSQnJ8mOHEcxOyZYWmM2Mr5oYUy+Glo=",
      "url": "_framework/System.IO.IsolatedStorage.hqyeyb5ipe.wasm"
    },
    {
      "hash": "sha256-WZLsRujfD/qa85HQq+jH/mNvqaSC8EfcorhN7V+E+I8=",
      "url": "_framework/System.IO.MemoryMappedFiles.zhamjnusxd.wasm"
    },
    {
      "hash": "sha256-TDz5qGlXb4ZW8yA27qUZMYc8j1MMcr9och2a7PScXg4=",
      "url": "_framework/System.IO.Pipelines.wrmw5vws31.wasm"
    },
    {
      "hash": "sha256-KsyFANWIAfdArrjBnJnX3LWpJAMzXAJi29tm3Kb5mgw=",
      "url": "_framework/System.IO.Pipes.AccessControl.qcancj8gj2.wasm"
    },
    {
      "hash": "sha256-OVQT1MG8JbyAXuZTrGXlrR+u0SL2S/0PT6accLkQu54=",
      "url": "_framework/System.IO.Pipes.zhcyguvwkr.wasm"
    },
    {
      "hash": "sha256-yHbYTenL8GXOuqqmxkdwREWeOUezLPi2eCSzn979C+k=",
      "url": "_framework/System.IO.UnmanagedMemoryStream.o8cpjnlard.wasm"
    },
    {
      "hash": "sha256-ay5ZQ8PHEUVWJdcCv/NrSw8QUTNKQlbtJ15E8LucrqU=",
      "url": "_framework/System.IdentityModel.Tokens.Jwt.zmzgmkn8sr.wasm"
    },
    {
      "hash": "sha256-mSgezbBarV5SBEY+t7LObP5nQ3XgEVF6R5qAhQY90so=",
      "url": "_framework/System.Linq.AsyncEnumerable.hyc0b7okjw.wasm"
    },
    {
      "hash": "sha256-yUg/PQ8henAChE7w0Fuf2GVEpweY2df9f20ChCg2GME=",
      "url": "_framework/System.Linq.Expressions.ldibvm0efj.wasm"
    },
    {
      "hash": "sha256-Eggt4fURp1Dc3UevhKbp4Lj9fjdjlc8/jGqM2ifdzIs=",
      "url": "_framework/System.Linq.Parallel.2buevezvch.wasm"
    },
    {
      "hash": "sha256-+OubGWG+/zfH+Fs0lXunuGpq8wzuc4YXIfJU2fHdzDA=",
      "url": "_framework/System.Linq.Queryable.cvq43g1awj.wasm"
    },
    {
      "hash": "sha256-4ROqweguD0hFn3XZ2XC+JKzncsxZNBiX2yeKPuQs9bM=",
      "url": "_framework/System.Linq.lz6mvi0hm2.wasm"
    },
    {
      "hash": "sha256-cV8BYmP+pMPC5iDRi3x21fsgc2dUObz+vFs7usZY2js=",
      "url": "_framework/System.Memory.3jekerw0ga.wasm"
    },
    {
      "hash": "sha256-SFmib3glSdfRTQZAtBg0AFgrNS9J3dUgpsDmt9X9vJE=",
      "url": "_framework/System.Net.Http.Json.8k237kkwec.wasm"
    },
    {
      "hash": "sha256-5EKrlM9SabAClzp0n57qTFE2eaLB+jP0/z1nRz/iwQk=",
      "url": "_framework/System.Net.Http.cityx2bvcl.wasm"
    },
    {
      "hash": "sha256-MOeibcHl0sx5SEqNQHQhRZOR598ACQUcNnX/FVecteo=",
      "url": "_framework/System.Net.HttpListener.s1jreclykx.wasm"
    },
    {
      "hash": "sha256-zNeqttiCsELKrGrpy/T5NQKxD09jocn8hXJv3BcfKo4=",
      "url": "_framework/System.Net.Mail.cmlj4c0gto.wasm"
    },
    {
      "hash": "sha256-ul/5prZbC0vGrIt6UESE+4lpJo/wXYgWcu+1+gAgc5k=",
      "url": "_framework/System.Net.NameResolution.q3gf18q13l.wasm"
    },
    {
      "hash": "sha256-+WqoHrz7stgVcQGbtpi7jQqel4rJ2hx2SF0HJokwHa8=",
      "url": "_framework/System.Net.NetworkInformation.xaz5tjw7d0.wasm"
    },
    {
      "hash": "sha256-5nvH8j0VIm/1nMN1+lVTI54Ri8D5ntm30A2fhB0hc/Q=",
      "url": "_framework/System.Net.Ping.a40atim1h0.wasm"
    },
    {
      "hash": "sha256-zhN/oiyikQbwjunDNbYt4XbUn3w/DgR7jOA8zD1phRA=",
      "url": "_framework/System.Net.Primitives.i88i20r8sr.wasm"
    },
    {
      "hash": "sha256-NQhcYyf0Hr4tfihcptLj6kjDKjbD3nIU6f7VUfP+jXk=",
      "url": "_framework/System.Net.Quic.hx06eo5xkj.wasm"
    },
    {
      "hash": "sha256-UdJOWmu1xm90dNiv+WiZLNoDnNaUDC8SByJPZAY/fSM=",
      "url": "_framework/System.Net.Requests.hkjxlfe5f5.wasm"
    },
    {
      "hash": "sha256-YMvWX7YyMp6BsYKuNwDVWeeq0qr6S82HoFuZJ08E3DY=",
      "url": "_framework/System.Net.Security.ch34yya69o.wasm"
    },
    {
      "hash": "sha256-qGmAP22IUTQuqxOQHHoMv2/ULrRmNDq/8/wmKKhaui0=",
      "url": "_framework/System.Net.ServerSentEvents.0u7o0jk3p1.wasm"
    },
    {
      "hash": "sha256-/STSB/pmoEd7eBP1ewThAYMeJGveTDOrKftoV06TyiI=",
      "url": "_framework/System.Net.ServicePoint.xbhxnytx4l.wasm"
    },
    {
      "hash": "sha256-vZEy2LgIvPJwM0p6XiZJMoT5fvBlV6yhrIf0ZiUU2Ok=",
      "url": "_framework/System.Net.Sockets.hzgzlvkc9l.wasm"
    },
    {
      "hash": "sha256-SAuUMWKRzK2wStVZ46JGxoZNUEPdH9QiUK2Psd4LYcc=",
      "url": "_framework/System.Net.WebClient.84i8nwzbgu.wasm"
    },
    {
      "hash": "sha256-ay8HWX3V52s3fo/zr8I3p76ZOdAuY0ecre1U2TCwOVI=",
      "url": "_framework/System.Net.WebHeaderCollection.326nl7s9g3.wasm"
    },
    {
      "hash": "sha256-kKO3TH8HsBXfC92Sy938oIV1HdKMS0uVpztIaUDDeU4=",
      "url": "_framework/System.Net.WebProxy.oq3mgkkqef.wasm"
    },
    {
      "hash": "sha256-/qUjzqNF74n5FiEQpOww2wGmAOT57HohJWFc6N/CtJc=",
      "url": "_framework/System.Net.WebSockets.2cx1v74vg8.wasm"
    },
    {
      "hash": "sha256-M2xvJviBA3wTLi4RJU+payoXVPiEryPgwyydiLJ04WA=",
      "url": "_framework/System.Net.WebSockets.Client.rafzkktw8j.wasm"
    },
    {
      "hash": "sha256-bE5JhulvXs+VFtgIW1IMKhELHc5gUDe0EPzNiDtoZpE=",
      "url": "_framework/System.Net.w1hpj3bo6r.wasm"
    },
    {
      "hash": "sha256-cK8cVJbRJLyKnySzrxM3O/YJXg8JlRarWMJAYxG2QcU=",
      "url": "_framework/System.Numerics.Vectors.oyv7biw9ux.wasm"
    },
    {
      "hash": "sha256-g5p6oqfQl2OUj/Or3JJiTCnkMEiv5Yl6r3Aki08Xdvc=",
      "url": "_framework/System.Numerics.lyu36wqn19.wasm"
    },
    {
      "hash": "sha256-aP1cHdnCvYP1drrICHt/oMYUqSOQVVVlW5fxAzhNYuE=",
      "url": "_framework/System.ObjectModel.kxu80demuu.wasm"
    },
    {
      "hash": "sha256-gzDngaKE1fzrenrnFvi+7MHiHJEUQn0brQD1g3Q+hFI=",
      "url": "_framework/System.Private.CoreLib.1vy46s12u6.wasm"
    },
    {
      "hash": "sha256-6jmrkfhbtGkAs8F0pAMzP0ymubYGNI7n7a1J2xY4y98=",
      "url": "_framework/System.Private.DataContractSerialization.ao8k9iu77a.wasm"
    },
    {
      "hash": "sha256-atgB1gY60K6/ntpQXNN8jsGpnw185Y8zBq6WNNt5LKg=",
      "url": "_framework/System.Private.Uri.itn0n2zjd0.wasm"
    },
    {
      "hash": "sha256-i9KhUrIpGVyhMpgL4GV/JczYp4NdDf+o18PilPlm48E=",
      "url": "_framework/System.Private.Xml.19nzpxrx8w.wasm"
    },
    {
      "hash": "sha256-beNcumb5VoNQYWiR9bxGCuUPTD15NSD6EqARdh9HU/Y=",
      "url": "_framework/System.Private.Xml.Linq.tw5eq1hjvo.wasm"
    },
    {
      "hash": "sha256-W9+0UBxtz0EvZ9xgkmng+tHOhXWW2GBKdjcZAVbc6YE=",
      "url": "_framework/System.Reflection.DispatchProxy.7lajnj8s8c.wasm"
    },
    {
      "hash": "sha256-JZK/huZ9doWYIPv0yzev1wYuhUXAIQrxo2NCyu7A1OA=",
      "url": "_framework/System.Reflection.Emit.7liz9zln06.wasm"
    },
    {
      "hash": "sha256-yfOooDyPto0Lng17CwgJ55NXqhWz+t9SfhiGJeT79HY=",
      "url": "_framework/System.Reflection.Emit.ILGeneration.1ut3qgacw8.wasm"
    },
    {
      "hash": "sha256-MwR9j/suPuezXSGdbNPU23VHe5GIBf6R9Bs1p9BtP3k=",
      "url": "_framework/System.Reflection.Emit.Lightweight.d0gvllb1jj.wasm"
    },
    {
      "hash": "sha256-/xKkpAsqwNQ8soTda97aUed6al1D9dGTdTA2lRvrLxM=",
      "url": "_framework/System.Reflection.Extensions.zr5bhwfczd.wasm"
    },
    {
      "hash": "sha256-tc7STzUxi0O+S8ivukRXeP7SVKVDwsqSYPtr8b0nhqQ=",
      "url": "_framework/System.Reflection.Metadata.ff6np6mz2j.wasm"
    },
    {
      "hash": "sha256-niYygMlK1HnbEugbNiTeBc7EkQIXXPnnZkgZUqq3qLs=",
      "url": "_framework/System.Reflection.Primitives.igpmvwv78c.wasm"
    },
    {
      "hash": "sha256-pt8RKbO93gvHhs2DfKf4ctYNpnH6Ec2j6l+M0SgdAS4=",
      "url": "_framework/System.Reflection.TypeExtensions.qouojzlnp9.wasm"
    },
    {
      "hash": "sha256-1k6WUVW1mJwUKSKAwvKj5wtG/WTYf3scCmFyc4uRtWs=",
      "url": "_framework/System.Reflection.mk3jyxvh13.wasm"
    },
    {
      "hash": "sha256-+DE3yDPtRF5JM8T52ycQt1qSAJ0vbjX5nu4Zoj+SuZ4=",
      "url": "_framework/System.Resources.Reader.41ppfyz2vc.wasm"
    },
    {
      "hash": "sha256-CIM4gUMmot/+RliOJhpf94ZlIsAr4YiEfWvOAXbovMU=",
      "url": "_framework/System.Resources.ResourceManager.sfwvfmw1ea.wasm"
    },
    {
      "hash": "sha256-Kx23sKGyz/kEgJVd1ZRRDUI93A95CFpkYIzCejkCxtQ=",
      "url": "_framework/System.Resources.Writer.3uvs9tp38z.wasm"
    },
    {
      "hash": "sha256-P6tIzozdCJqHiy0zGjuPtLVfOYb5yb0QPwFMwMUn4AY=",
      "url": "_framework/System.Runtime.CompilerServices.Unsafe.puz1xm53oc.wasm"
    },
    {
      "hash": "sha256-/4HwDzaQ5a7S2V+Qzr94Nz3zi91/aZ30tRhta0XKqYE=",
      "url": "_framework/System.Runtime.CompilerServices.VisualC.9qdau315py.wasm"
    },
    {
      "hash": "sha256-Mnk3n1eK4eqTEZkm/ZfT7LQmGdwGAoF2anLqrZbDPbM=",
      "url": "_framework/System.Runtime.Extensions.i7gntui96b.wasm"
    },
    {
      "hash": "sha256-QIVT4ckpz17JUAEsvaaKYYH35Ou8V9ErIKuwNI05CZU=",
      "url": "_framework/System.Runtime.Handles.00oxj4o6ov.wasm"
    },
    {
      "hash": "sha256-uQsOh1GEq2ZX0sXBxXnyoYzNMf4yeXUeLKUgb1q0fKo=",
      "url": "_framework/System.Runtime.InteropServices.JavaScript.9kq1vofond.wasm"
    },
    {
      "hash": "sha256-zhC5CCW9nCkqGXdOfIfwawjFHi5JjlQNnD8pGkdfWoE=",
      "url": "_framework/System.Runtime.InteropServices.RuntimeInformation.my7qeqbhfh.wasm"
    },
    {
      "hash": "sha256-Vzg1KlSYjHMKB8KW97OKaZsRei8Q593KoPgnQe1n5Uo=",
      "url": "_framework/System.Runtime.InteropServices.vqp80tnwc7.wasm"
    },
    {
      "hash": "sha256-Xo6xM56FQTZ30/6Vggp3fYR+4FxV/KmMooNBNpt+w6I=",
      "url": "_framework/System.Runtime.Intrinsics.u0samjybfo.wasm"
    },
    {
      "hash": "sha256-X+RMnAfTVC4+TDBQoS/h7LhyPBwJjorpoELFBfV7248=",
      "url": "_framework/System.Runtime.Loader.n6zxw1b98a.wasm"
    },
    {
      "hash": "sha256-qDYDPlthKrlj2dnaBsNoMK5X/nxKhTIdUiQ9ugVTuW0=",
      "url": "_framework/System.Runtime.Numerics.o40sjhz59x.wasm"
    },
    {
      "hash": "sha256-h/dAFonk9eigobeeUZLSOdbPf0Gz2On4fYCbW4hGwmk=",
      "url": "_framework/System.Runtime.Serialization.Formatters.1esvva4te3.wasm"
    },
    {
      "hash": "sha256-MCbIAsHQBugo8qpJp51Z0UHPviJI013X8cqoUXXfa7M=",
      "url": "_framework/System.Runtime.Serialization.Json.4n7u09advh.wasm"
    },
    {
      "hash": "sha256-DzErfw7r3LKDKFr89PBxgF+SxxMEJcb6lGnpmdvn3A8=",
      "url": "_framework/System.Runtime.Serialization.Primitives.xs2bo91wvk.wasm"
    },
    {
      "hash": "sha256-P4CWph0hEmcsfiwKYkRp4me/5o8puJqWxBfj0AcLfWk=",
      "url": "_framework/System.Runtime.Serialization.Xml.ny21jmziti.wasm"
    },
    {
      "hash": "sha256-pr4aZh6q8+LiDRjtVtJkkLeCZuVgRF9iOhru3cXTfUY=",
      "url": "_framework/System.Runtime.Serialization.qcxaur5wqs.wasm"
    },
    {
      "hash": "sha256-dJxxG1+xZ1brKjnFZcEsO69maKgVzhnw94U5gUor6Gs=",
      "url": "_framework/System.Runtime.odq454d6j9.wasm"
    },
    {
      "hash": "sha256-gCsoRrVikUlzNxsrNbZ+6QVGT2+XUPKJWx95hBKEl/w=",
      "url": "_framework/System.Security.AccessControl.8yfnzmqzaq.wasm"
    },
    {
      "hash": "sha256-GPcSbHwWVLH1fca0stI2MqZE+xsVLrA/kskuiQycJ4Q=",
      "url": "_framework/System.Security.Claims.8ogy0860de.wasm"
    },
    {
      "hash": "sha256-LDzYiGnR0brxYcFNo0ocBo59dYZZb9MBe3ild2znJSc=",
      "url": "_framework/System.Security.Cryptography.Algorithms.8zijp1svfw.wasm"
    },
    {
      "hash": "sha256-ZpyrNDtC+3ti6m3d6mhH1as/m+ZFqLtc2bZBFNtuVH8=",
      "url": "_framework/System.Security.Cryptography.Cng.yxagtt77no.wasm"
    },
    {
      "hash": "sha256-Mp7WemXwikMFbyEZOblQA8l8wqAZ5jhmh6QboTii32o=",
      "url": "_framework/System.Security.Cryptography.Csp.uhfbvvau84.wasm"
    },
    {
      "hash": "sha256-duIpVcBN7g31lDD77yYuAG3xM3U5GZtePHznUiVz0m4=",
      "url": "_framework/System.Security.Cryptography.Encoding.2ywrusvy8q.wasm"
    },
    {
      "hash": "sha256-4H6EYIOcQKX7spTR+G74jmTVJg6+MgAtY9g8b22KcFg=",
      "url": "_framework/System.Security.Cryptography.OpenSsl.oa268u7i92.wasm"
    },
    {
      "hash": "sha256-DX5w2C46UrZY0ubTaEn3lxmlfYnJFHE1TN8wI4qsMgc=",
      "url": "_framework/System.Security.Cryptography.Primitives.5uhvqe8puk.wasm"
    },
    {
      "hash": "sha256-wnRBilXju2GhWZsScBp6pBZ8dNSD81FuW+DXXZxUu1I=",
      "url": "_framework/System.Security.Cryptography.X509Certificates.6i7pxilopt.wasm"
    },
    {
      "hash": "sha256-LZkStq41MX59Tptph5/JGQRSG8B5+a1ldrb0QpNVB6I=",
      "url": "_framework/System.Security.Cryptography.d0quqk1iyr.wasm"
    },
    {
      "hash": "sha256-TNOfYwVGiv+d/Xk6LXgrOyiDkxGzv9NyH2IGyuVIMR4=",
      "url": "_framework/System.Security.Principal.Windows.gpqua4rz29.wasm"
    },
    {
      "hash": "sha256-Wow4n7EbYXc1HfQqHQu1Jhl7f8vCrcVNkFAXLZvyvTg=",
      "url": "_framework/System.Security.Principal.i20kfklf3g.wasm"
    },
    {
      "hash": "sha256-d7gVbpst3NnK88ZEcpaJoH5w3zfmsRXDJQvvqbL+RVY=",
      "url": "_framework/System.Security.SecureString.x2y8tzci3c.wasm"
    },
    {
      "hash": "sha256-HuX7LBO46UViQb2u/0vvs+XLxgVQE+KVlOs6UH+Gw0g=",
      "url": "_framework/System.Security.e83vvh6sl2.wasm"
    },
    {
      "hash": "sha256-R4tw5kXVUZ+Qsq6/4Xkq7Qedv5pzouTdXVacoeG0V/0=",
      "url": "_framework/System.ServiceModel.Web.poglliv2no.wasm"
    },
    {
      "hash": "sha256-Usmz3M5o5WSM1Sc2dU3njqXU1MeSMvgc8oaxTK8gBGo=",
      "url": "_framework/System.ServiceProcess.yro5uj2opo.wasm"
    },
    {
      "hash": "sha256-giy48Parl41Ox46pfccHLTXlypNv3dXKu+yRKiWcJC0=",
      "url": "_framework/System.Text.Encoding.CodePages.2wchx40i7z.wasm"
    },
    {
      "hash": "sha256-kL2CE+V74498vfb1kuYNsti2ylJDViK5eEnTmKJv+54=",
      "url": "_framework/System.Text.Encoding.Extensions.8utaw61kn5.wasm"
    },
    {
      "hash": "sha256-AM6c0tx+lLrDZ6OZN3oLhe6nC21LZ6j1sEKHYC0gX9Q=",
      "url": "_framework/System.Text.Encoding.cxdyfepnpj.wasm"
    },
    {
      "hash": "sha256-H0VkIeM0rlJX/Veq/zPhEyH7piskV3JOKngzP/djJE8=",
      "url": "_framework/System.Text.Encodings.Web.37ehbi7cye.wasm"
    },
    {
      "hash": "sha256-qsdCabiszf3qHMsvYiRuxa71WNCjNekpqBRHs8469vQ=",
      "url": "_framework/System.Text.Json.ixiaa8hd3h.wasm"
    },
    {
      "hash": "sha256-7msxYtUuVfZjmYO75wrZGO6rapEVdjT7RCgt6Y9EyGc=",
      "url": "_framework/System.Text.RegularExpressions.2fhfmkk6vf.wasm"
    },
    {
      "hash": "sha256-ulcimTPEQYo+vzvzjcj97+VdF4TYl1acGxv2F4064sc=",
      "url": "_framework/System.Threading.6pry74a050.wasm"
    },
    {
      "hash": "sha256-z0hatN5fwMJgHdz4QHMG8+e9nDMcL+jWvoEY/4+50K8=",
      "url": "_framework/System.Threading.AccessControl.76zfdfy8go.wasm"
    },
    {
      "hash": "sha256-ZFVZEgZJ4fAvrAa84Zoj5j1OLX+7VhF5jq0XJoGdPX0=",
      "url": "_framework/System.Threading.Channels.gpxnr01lmp.wasm"
    },
    {
      "hash": "sha256-goELF2wzUusbMI1lATDF4myHde5GT8E3X4qmtHFNOeg=",
      "url": "_framework/System.Threading.Overlapped.aqpl8tzdyc.wasm"
    },
    {
      "hash": "sha256-dkzneK8QtxQQ6flGCimi/ofDvV+VowH1LcxXReD935E=",
      "url": "_framework/System.Threading.Tasks.Dataflow.ytwttt7fzh.wasm"
    },
    {
      "hash": "sha256-NEYDYaYBpgF3So553VgamGq3KZUL32UDvps2Y/dLdis=",
      "url": "_framework/System.Threading.Tasks.Extensions.0deavcb00v.wasm"
    },
    {
      "hash": "sha256-97xFkzLi4/C0otWqBmpjcxGrMAFBRhu4b29HpMXaTZw=",
      "url": "_framework/System.Threading.Tasks.Parallel.tjwtxugso0.wasm"
    },
    {
      "hash": "sha256-+TOeSAsKIGT1UJBmjHRX61gRkGIQ+0vEtBQr8k+7HlI=",
      "url": "_framework/System.Threading.Tasks.fu4qd5h3qy.wasm"
    },
    {
      "hash": "sha256-KFOGstVXEAMQHwhfWTIZj3A5HwiPl+KlgZetTOfe0cY=",
      "url": "_framework/System.Threading.Thread.klaua2by9m.wasm"
    },
    {
      "hash": "sha256-atxs3p14Jj6AnnJM+AEdbVR3Le/oST9CtB8bz0mcM5U=",
      "url": "_framework/System.Threading.ThreadPool.mkzm212njz.wasm"
    },
    {
      "hash": "sha256-2rbLSkDUh/CdKMUXN12xK590P5PdtQ6+D/HUF1Y2zNY=",
      "url": "_framework/System.Threading.Timer.yp49llu5h2.wasm"
    },
    {
      "hash": "sha256-lTkTSlfTqj7jJYcWurf1fHboUKCwCLKHNyJpgQFQy1E=",
      "url": "_framework/System.Transactions.Local.vz6cgeh4w7.wasm"
    },
    {
      "hash": "sha256-6kE7mivQoxfhMTVAkmYi5VlsQhqXLYcImAuc9D7Skjo=",
      "url": "_framework/System.Transactions.ipwm3rsy66.wasm"
    },
    {
      "hash": "sha256-yctvPmRbtoHiPpM5pKnajABrjRQR9a3b+HPWHyga2kY=",
      "url": "_framework/System.ValueTuple.7ol6ljuhx8.wasm"
    },
    {
      "hash": "sha256-Nhc8L23J1+APB7ju97KZlDcnoEa6XvC6p4LluoAjVkY=",
      "url": "_framework/System.Web.HttpUtility.itlvncjd96.wasm"
    },
    {
      "hash": "sha256-m5aBz++zzF8tNzlN4+R5pPqGhS882Pxw4KwoakadVrI=",
      "url": "_framework/System.Web.np8uzzakvl.wasm"
    },
    {
      "hash": "sha256-r62brvRKMGvdcIg3SIbWWi7k8/NqCfpn+LPqnwitvKE=",
      "url": "_framework/System.Windows.18nzio44t3.wasm"
    },
    {
      "hash": "sha256-KPyqHJl+ZMo3c6PCl2vPaQGBdD8P4KUBxsUkvR90/hk=",
      "url": "_framework/System.Xml.45jprtg1pa.wasm"
    },
    {
      "hash": "sha256-rQ0vSy0Z16GnVFmS/wCs02+prtLem1HSrbHdfWIzNK4=",
      "url": "_framework/System.Xml.Linq.v9v8udncm1.wasm"
    },
    {
      "hash": "sha256-bmkzRCDnwMgFnyZvQKnjJh5rdfZJtZ4nirjaJufIrqk=",
      "url": "_framework/System.Xml.ReaderWriter.a9mr08uzci.wasm"
    },
    {
      "hash": "sha256-HPQyo7cnsrAul9FfHP0JLVYXonc/DYwM87t6IXA4jPc=",
      "url": "_framework/System.Xml.Serialization.03juoguwgc.wasm"
    },
    {
      "hash": "sha256-YLwIjMK8F1xq/FIgzG6+jiJStkbL+5sLQLdzD2sgpa8=",
      "url": "_framework/System.Xml.XDocument.c9dhjnzqjb.wasm"
    },
    {
      "hash": "sha256-rUb1sC2EPqYnLys9V/C0H/313aLByFrqm0qT6zJpUcE=",
      "url": "_framework/System.Xml.XPath.XDocument.138b12i1pm.wasm"
    },
    {
      "hash": "sha256-+5VqXw8HmAjDvyi2+y7K95eMarW7XY4wPW0bh7x8L/I=",
      "url": "_framework/System.Xml.XPath.pvxm9341ce.wasm"
    },
    {
      "hash": "sha256-uPwda+H2hEsj0Jbt2bXGnSVbjkdbRsFU3TjifwMLQi4=",
      "url": "_framework/System.Xml.XmlDocument.450wsyxvl0.wasm"
    },
    {
      "hash": "sha256-IrnG91lN1tfKsabToUYpusckhRr9wXb3Jxm6CqsOTJE=",
      "url": "_framework/System.Xml.XmlSerializer.y3t2n0tce7.wasm"
    },
    {
      "hash": "sha256-7DGslki9AfExPpvTTP5Lou+UeVMPtxC7TMoTwvo5sKY=",
      "url": "_framework/System.gjriafnqmz.wasm"
    },
    {
      "hash": "sha256-tI94+TOjFqR3Z880lf+2Ye9R7uo6OxX3t73SZC3Wodc=",
      "url": "_framework/WindowsBase.8zsce9qxfb.wasm"
    },
    {
      "hash": "sha256-lDXsDYFgm62F+YUvxES7IOTCXYpiHpU3uR45YdC6mq4=",
      "url": "_framework/blazor.webassembly.js"
    },
    {
      "hash": "sha256-HgyKgXuQEQ9Io1InzkgbQdN6tnn51v8lzrEmJiMbOXw=",
      "url": "_framework/dotnet.js"
    },
    {
      "hash": "sha256-3wG4X/zoSm1xUIuhv0i8hePrWxX+85o7HkuXX9jRXeg=",
      "url": "_framework/dotnet.js.map"
    },
    {
      "hash": "sha256-//GZeYgjUoxGpPK0TDGntOZk0L95XIFJV8EA+7Wfffk=",
      "url": "_framework/dotnet.native.3zpaws0drs.wasm"
    },
    {
      "hash": "sha256-BtUMevCTTpUK4I5d68LtBZlJdGIQC7fk+oNnjyzuFR4=",
      "url": "_framework/dotnet.native.q38003gvqi.js"
    },
    {
      "hash": "sha256-muN076HgyOCoAaid7zD7a2/GN7aQ7tmK/BzdnKgw78g=",
      "url": "_framework/dotnet.runtime.azrfhwb804.js"
    },
    {
      "hash": "sha256-4QJPb/m7QLAyLjxKGCKEDkvqEn3GyQYa8Zo93Tiw9tk=",
      "url": "_framework/dotnet.runtime.js.map"
    },
    {
      "hash": "sha256-SZLtQnRc0JkwqHab0VUVP7T3uBPSeYzxzDnpxPpUnHk=",
      "url": "_framework/icudt_CJK.tjcz0u77k5.dat"
    },
    {
      "hash": "sha256-8fItetYY8kQ0ww6oxwTLiT3oXlBwHKumbeP2pRF4yTc=",
      "url": "_framework/icudt_EFIGS.tptq2av103.dat"
    },
    {
      "hash": "sha256-L7sV7NEYP37/Qr2FPCePo5cJqRgTXRwGHuwF5Q+0Nfs=",
      "url": "_framework/icudt_no_CJK.lfu7j35m59.dat"
    },
    {
      "hash": "sha256-3H2G5ngT7eIaYsTDs+CoGgdvfTchxty175b/4H9+qxI=",
      "url": "_framework/mscorlib.8ptuc08eli.wasm"
    },
    {
      "hash": "sha256-dtyh2m2c4Ak4ASCotVspn+EmOiuXkI5zqS2q90qHb+s=",
      "url": "_framework/netstandard.eymp85mooh.wasm"
    },
    {
      "hash": "sha256-b8826O1IyDfWxerbhUGfSW8dsfM3CjciXHEyimAggPs=",
      "url": "css/app.css"
    },
    {
      "hash": "sha256-4mWsDy3aHl36ZbGt8zByK7Pvd4kRUoNgTYzRnwmPHwg=",
      "url": "favicon.png"
    },
    {
      "hash": "sha256-DbpQaq68ZSb5IoPosBErM1QWBfsbTxpJqhU0REi6wP4=",
      "url": "icon-192.png"
    },
    {
      "hash": "sha256-oEo6d+KqX5fjxTiZk/w9NB3Mi0+ycS5yLwCKwr4IkbA=",
      "url": "icon-512.png"
    },
    {
      "hash": "sha256-sz0gYf/lEKNYDjvnzx1d7FSf76FEq9TFvD2ju/bnMYg=",
      "url": "index.html"
    },
    {
      "hash": "sha256-Eg1IOjMTDw2QIaNk/ZbJtx++jFMiu3S+REw43ajWaic=",
      "url": "js/offline.js"
    },
    {
      "hash": "sha256-f4c8YV1qrr6RSiVYWMQT7R5W2OkT+iXmE5H69/uRvGQ=",
      "url": "lib/bootstrap/dist/css/bootstrap-grid.css"
    },
    {
      "hash": "sha256-xAT+n25FE5hvOjj2fG4YdOwr1bl4IlAJBNg6PbhLT2E=",
      "url": "lib/bootstrap/dist/css/bootstrap-grid.css.map"
    },
    {
      "hash": "sha256-hN2ttMG/K3wQlFrN3SbQ1YF4tIJHCE4oYP+QibT3vOY=",
      "url": "lib/bootstrap/dist/css/bootstrap-grid.min.css"
    },
    {
      "hash": "sha256-kgL+xwVmM8IOs15lnoHt9daR2LRMiBG/cYgUPcKQOY4=",
      "url": "lib/bootstrap/dist/css/bootstrap-grid.min.css.map"
    },
    {
      "hash": "sha256-M15fHTKfMK6cTars5c28PNhN6hD0qeUb3HPzOdoPwCc=",
      "url": "lib/bootstrap/dist/css/bootstrap-grid.rtl.css"
    },
    {
      "hash": "sha256-/siQUA8yX830j+cL4amKHY3yBtn3n8z3Eg+VZ15f90k=",
      "url": "lib/bootstrap/dist/css/bootstrap-grid.rtl.css.map"
    },
    {
      "hash": "sha256-+rGG3u63SMkHL80Ga42LAawPUj7i8vaR2Kuenqlta2E=",
      "url": "lib/bootstrap/dist/css/bootstrap-grid.rtl.min.css"
    },
    {
      "hash": "sha256-7GdOlw7U/wgyaeUtFmxPz5/MphdvVSPtVOOlTn9c33Q=",
      "url": "lib/bootstrap/dist/css/bootstrap-grid.rtl.min.css.map"
    },
    {
      "hash": "sha256-rjusxCRzKjztCcfgOVduAc3e3Z7KvimJGokJSeADNmE=",
      "url": "lib/bootstrap/dist/css/bootstrap-reboot.css"
    },
    {
      "hash": "sha256-RXJ/QZiBfHXoPtXR2EgC+bFo2pe3GtbZO722RtiLGzQ=",
      "url": "lib/bootstrap/dist/css/bootstrap-reboot.css.map"
    },
    {
      "hash": "sha256-y72bT5TKmFmfvw3bNEzPRNZa/8595xtseZIcBUV0PdM=",
      "url": "lib/bootstrap/dist/css/bootstrap-reboot.min.css"
    },
    {
      "hash": "sha256-0eqVT62kqRLJh9oTqLeIH4UnQskqVjib8hl2fXxl4lg=",
      "url": "lib/bootstrap/dist/css/bootstrap-reboot.min.css.map"
    },
    {
      "hash": "sha256-gRKIHVkBgnCPUs/hmZsXynZ9ZJpvsE77idtljDkrWGI=",
      "url": "lib/bootstrap/dist/css/bootstrap-reboot.rtl.css"
    },
    {
      "hash": "sha256-OoQVwh7Arp7bVoK2ZiTx2S//KrnPrSPzPZ93CqCMhe8=",
      "url": "lib/bootstrap/dist/css/bootstrap-reboot.rtl.css.map"
    },
    {
      "hash": "sha256-UkajePbMzGj8y73Imkd3dWWnLJr0v2CrBCLMrVMleP8=",
      "url": "lib/bootstrap/dist/css/bootstrap-reboot.rtl.min.css"
    },
    {
      "hash": "sha256-910zw+rMdcg0Ls48ATp65vEn8rd5HvPxOKm2x3/CBII=",
      "url": "lib/bootstrap/dist/css/bootstrap-reboot.rtl.min.css.map"
    },
    {
      "hash": "sha256-uIzOR4gILoNjCGNryIsWnkEGO3BSwRa/MLjr73tDodE=",
      "url": "lib/bootstrap/dist/css/bootstrap-utilities.css"
    },
    {
      "hash": "sha256-Nfjrc4Ur9Fv2oBEswQWIyBnNDP99q+LhL+z9553O0cY=",
      "url": "lib/bootstrap/dist/css/bootstrap-utilities.css.map"
    },
    {
      "hash": "sha256-ZBXbYF8OZrF1GDOLMLvW/zRPtx1RfeMDYj5D2Wb/9jo=",
      "url": "lib/bootstrap/dist/css/bootstrap-utilities.min.css"
    },
    {
      "hash": "sha256-rHDmip4JZzuaGOcSQ1QSQrIbG0Eb3Zja9whqSF1zYIU=",
      "url": "lib/bootstrap/dist/css/bootstrap-utilities.min.css.map"
    },
    {
      "hash": "sha256-MwFckg8YbY2WrveNQnXkfULkprYhFOq+t1BH92A7GsI=",
      "url": "lib/bootstrap/dist/css/bootstrap-utilities.rtl.css"
    },
    {
      "hash": "sha256-p0BVq5Ve/dohBIdfbrZsoQNu02JSsKh1g0wbyiQiUaU=",
      "url": "lib/bootstrap/dist/css/bootstrap-utilities.rtl.css.map"
    },
    {
      "hash": "sha256-7MYEMUFgHEc1CjrfAK/TlV30POxgoxXk2b+vAs/143U=",
      "url": "lib/bootstrap/dist/css/bootstrap-utilities.rtl.min.css"
    },
    {
      "hash": "sha256-o8XK32mcY/FfcOQ1D2HJvVuZ0YTXSURZDLXCK0fnQeA=",
      "url": "lib/bootstrap/dist/css/bootstrap-utilities.rtl.min.css.map"
    },
    {
      "hash": "sha256-CzmECrtXV8BSk/+8SG+Rw7Fr+3hCt2bS2bEkS4YD3PQ=",
      "url": "lib/bootstrap/dist/css/bootstrap.css"
    },
    {
      "hash": "sha256-KzNVR3p7UZGba94dnCtlc6jXjK5urSPiZ/eNnKTmDkw=",
      "url": "lib/bootstrap/dist/css/bootstrap.css.map"
    },
    {
      "hash": "sha256-sKIQRfQriISuQ9l/44b1zHfQniGXJhGonVtB2LlSuIs=",
      "url": "lib/bootstrap/dist/css/bootstrap.min.css"
    },
    {
      "hash": "sha256-8SM4U2NQpCLGTQLW5D/x3qSTwxVq2CP+GXYc3V1WwFs=",
      "url": "lib/bootstrap/dist/css/bootstrap.min.css.map"
    },
    {
      "hash": "sha256-/rceNUMI0RlFJugRzjua815bgXwawEJBGBPh4Vx3r38=",
      "url": "lib/bootstrap/dist/css/bootstrap.rtl.css"
    },
    {
      "hash": "sha256-3bYWUiiVYMZfv2wq5JnXIsHlQKgSKs/VcRivgjgZ1ho=",
      "url": "lib/bootstrap/dist/css/bootstrap.rtl.css.map"
    },
    {
      "hash": "sha256-rI1w2GDxZPCr77bpZIGQ8mUvMVtEr+gBtahl5RIPJpA=",
      "url": "lib/bootstrap/dist/css/bootstrap.rtl.min.css"
    },
    {
      "hash": "sha256-rTzXlnepcb/vgFAiB+U7ODQAfOlJLfM3gY6IU7eIANk=",
      "url": "lib/bootstrap/dist/css/bootstrap.rtl.min.css.map"
    },
    {
      "hash": "sha256-gR7NmqDcnlSIBNsf3p3DcKyJxcRdvSMp7pniI3QT/3Y=",
      "url": "lib/bootstrap/dist/js/bootstrap.bundle.js"
    },
    {
      "hash": "sha256-ADEXOfEUSkfFzqvEXJXbsbreZ3xy0ekmkkGLa/sOi6E=",
      "url": "lib/bootstrap/dist/js/bootstrap.bundle.js.map"
    },
    {
      "hash": "sha256-6zfk2L8R3wCgRbZzpkEi7UYC2bc6fYGIgFfNeqyOWnQ=",
      "url": "lib/bootstrap/dist/js/bootstrap.bundle.min.js"
    },
    {
      "hash": "sha256-BNd/F4Qb9/XaW+dQmPRe0fLDby7OTtEAscQDM8NEYk4=",
      "url": "lib/bootstrap/dist/js/bootstrap.bundle.min.js.map"
    },
    {
      "hash": "sha256-3uomEeumg3qJUE5P4N3kleojTGR+QpyPjPcORvyd6CE=",
      "url": "lib/bootstrap/dist/js/bootstrap.esm.js"
    },
    {
      "hash": "sha256-18dnhM3mfIc7+jiqyWcWiOlM484c3PScI/MOUkSFia8=",
      "url": "lib/bootstrap/dist/js/bootstrap.esm.js.map"
    },
    {
      "hash": "sha256-REjSeieVKd00nAKwd6dv7MMhuVKvKctPmLI4iDRs/cc=",
      "url": "lib/bootstrap/dist/js/bootstrap.esm.min.js"
    },
    {
      "hash": "sha256-qg29M9L0ub+gVWVoPryMeby6EdeAOakemc3clA+Ton4=",
      "url": "lib/bootstrap/dist/js/bootstrap.esm.min.js.map"
    },
    {
      "hash": "sha256-hhgn6ntO1fSzy4RUwzQeJ+96oyydQ1R39yXXwA349qY=",
      "url": "lib/bootstrap/dist/js/bootstrap.js"
    },
    {
      "hash": "sha256-JTtZaKPrZS15ryrBGdSkDG5Xh/u1j9w4Mt8zPv/de8I=",
      "url": "lib/bootstrap/dist/js/bootstrap.js.map"
    },
    {
      "hash": "sha256-aCTIqw9op0XQGYnNe1649V7fnihACD48OP3M8BP2xVM=",
      "url": "lib/bootstrap/dist/js/bootstrap.min.js"
    },
    {
      "hash": "sha256-De0sF9esziQNdfl0pAVTCpHrulCYvCjhgupkFEMbDCc=",
      "url": "lib/bootstrap/dist/js/bootstrap.min.js.map"
    },
    {
      "hash": "sha256-/F93WUBzjBJqM288qXqHr8OBjYVorakgTPXuafhbAZg=",
      "url": "manifest.json"
    },
    {
      "hash": "sha256-enKgCMkYmCpfEcmg6Annbmc40VZ/A6aYYSQjZfVn2cU=",
      "url": "sample-data/weather.json"
    }
  ]
};
